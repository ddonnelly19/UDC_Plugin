/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

public class ServerConfig implements Cloneable
{
    String label;
    String server;
    int port;
    String username;
    String password;
    String protocol;
    
    public ServerConfig(final String label, final String server, final int port, final String username, final String password, final String protocol) {
        this.port = 8080;
        this.label = label;
        this.server = server;
        this.port = port;
        this.username = username;
        this.password = password;
        this.protocol = protocol;
    }
    
    public ServerConfig() {
        this.port = 8080;
    }
    
    public ServerConfig(final ServerConfig serverConfig) {
        this.port = 8080;
        this.label = serverConfig.label;
        this.server = serverConfig.server;
        this.port = serverConfig.port;
        this.username = serverConfig.username;
        this.password = serverConfig.password;
        this.protocol = serverConfig.protocol;
    }
    
    @Override
    protected ServerConfig clone() {
        return new ServerConfig(this);
    }
    
    public String getServer() {
        return this.server;
    }
    
    public String getLabel() {
        return this.label;
    }
    
    public void setLabel(final String label) {
        this.label = label;
    }
    
    public void setServer(final String server) {
        this.server = server;
    }
    
    public int getPort() {
        return this.port;
    }
    
    public void setPort(final int port) {
        this.port = port;
    }
    
    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(final String username) {
        this.username = username;
    }
    
    public String getPassword() throws Exception {
        return this.password;
    }
    
    public void setPassword(final String password) {
        this.password = password;
    }
    
    public String getProtocol() {
        return this.protocol;
    }
    
    public void setProtocol(final String protocol) {
        this.protocol = protocol;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ServerConfig that = (ServerConfig)o;
        if (this.port != that.port) {
            return false;
        }
        Label_0075: {
            if (this.label != null) {
                if (this.label.equals(that.label)) {
                    break Label_0075;
                }
            }
            else if (that.label == null) {
                break Label_0075;
            }
            return false;
        }
        Label_0108: {
            if (this.password != null) {
                if (this.password.equals(that.password)) {
                    break Label_0108;
                }
            }
            else if (that.password == null) {
                break Label_0108;
            }
            return false;
        }
        Label_0141: {
            if (this.server != null) {
                if (this.server.equals(that.server)) {
                    break Label_0141;
                }
            }
            else if (that.server == null) {
                break Label_0141;
            }
            return false;
        }
        if (this.username != null) {
            if (this.username.equals(that.username)) {
                return true;
            }
        }
        else if (that.username == null) {
            return true;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        int result = (this.label != null) ? this.label.hashCode() : 0;
        result = 31 * result + ((this.server != null) ? this.server.hashCode() : 0);
        result = 31 * result + this.port;
        result = 31 * result + ((this.username != null) ? this.username.hashCode() : 0);
        result = 31 * result + ((this.password != null) ? this.password.hashCode() : 0);
        return result;
    }
    
    @Override
    public String toString() {
        return this.label + " (" + this.server + ")";
    }
}