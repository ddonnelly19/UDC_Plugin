/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import com.intellij.util.messages.Topic;

public interface DefaultServerChangeListener
{
    public static final Topic<DefaultServerChangeListener> TOPIC = Topic.create(DefaultServerChangeListener.class.getName(), (Class)DefaultServerChangeListener.class);
    
    void defaultServerChanged();
}