/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.model;

public class PackageTable
{
    private String packageName;
    private boolean selected;
    
    public String getPackageName() {
        return this.packageName;
    }
    
    public void setPackageName(final String packageName) {
        this.packageName = packageName;
    }
    
    public boolean isSelected() {
        return this.selected;
    }
    
    public void setSelected(final boolean selected) {
        this.selected = selected;
    }
    
    public PackageTable(final String packageName, final boolean selected) {
        this.packageName = packageName;
        this.selected = selected;
    }
}