/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.model;

import java.util.Date;

public interface IResource
{
    String getName();
    
    void setName(final String p0);
    
    Date getUpdateTime();
    
    void setUpdateTime(final Date p0);
}