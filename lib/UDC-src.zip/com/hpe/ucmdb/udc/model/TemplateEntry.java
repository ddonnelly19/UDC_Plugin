/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.model;

import java.util.List;

public class TemplateEntry
{
    private String templateName;
    private List<String> folder;
    private String file;
    
    public TemplateEntry(final String templateName, final List<String> folder, final String file) {
        this.templateName = templateName;
        this.folder = folder;
        this.file = file;
    }
    
    public String getTemplateName() {
        return this.templateName;
    }
    
    public List<String> getFolder() {
        return this.folder;
    }
    
    public String getFile() {
        return this.file;
    }
}