/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.util.concurrent.TimeUnit;
import java.util.TimerTask;
import java.util.Timer;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.components.ProjectComponent;

public class UDCProject implements ProjectComponent
{
    private Project project;
    
    public UDCProject(final Project project) {
        this.project = project;
    }
    
    public void initComponent() {
    }
    
    public void disposeComponent() {
    }
    
    @NotNull
    public String getComponentName() {
        final String s = "UDCProject";
        if (s == null) {
            throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/UDCProject", "getComponentName"));
        }
        return s;
    }
    
    public void projectOpened() {
        StatusBarUtil.setDefaultServerStatus(this.project);
        this.syncPool();
    }
    
    private void syncPool() {
        System.out.println("Sync pool");
        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    UcmdbClient.refreshPool();
                }
                catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        }, TimeUnit.SECONDS.toMillis(10L), TimeUnit.MINUTES.toMillis(10L));
    }
    
    public void projectClosed() {
    }
}