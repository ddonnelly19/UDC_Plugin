/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.util.HashMap;
import java.lang.reflect.Method;
import com.hp.ucmdb.api.resources.ResourceManagementService;
import java.util.Iterator;
import com.hp.ucmdb.api.discovery.services.DDMManagementService;
import java.util.HashSet;
import java.util.ArrayList;
import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import com.hp.ucmdb.api.discovery.types.DiscoveryResData;
import java.util.Collection;
import com.hp.ucmdb.api.discovery.services.DDMConfigurationService;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import com.hp.ucmdb.api.ClientContext;
import com.hp.ucmdb.api.Credentials;
import com.hp.ucmdb.api.UcmdbServiceProvider;
import com.hp.ucmdb.api.UcmdbServiceFactory;
import com.hp.ucmdb.api.UcmdbVersion;
import com.intellij.openapi.project.Project;
import java.util.Map;
import com.hp.ucmdb.api.UcmdbService;

public class UcmdbClient
{
    ServerConfig serverConfig;
    boolean isConnect;
    UcmdbService ucmdbService;
    private static UcmdbClient currentClient;
    private static Map<String, UcmdbClient> clientPool;
    
    public UcmdbClient(final ServerConfig serverConfig) {
        this.serverConfig = serverConfig.clone();
    }
    
    public static UcmdbClient getUcmdbClient(final Project project) throws Exception {
        if (UcmdbClient.currentClient != null) {
            validateConfig(project);
        }
        final ServerConfig config = ServerConfigManager.getInstance().getDefaultServerConfig(project);
        if (UcmdbClient.currentClient == null) {
            final UcmdbClient uc = UcmdbClient.clientPool.get(config.getLabel());
            if (uc != null) {
                UcmdbClient.currentClient = uc;
            }
        }
        if (UcmdbClient.currentClient == null) {
            UcmdbClient.currentClient = new UcmdbClient(config);
        }
        UcmdbClient.currentClient = testConnection(UcmdbClient.currentClient, config);
        UcmdbClient.clientPool.put(config.getLabel(), UcmdbClient.currentClient);
        return UcmdbClient.currentClient;
    }
    
    public static UcmdbClient getUcmdbClient(final ServerConfig config) throws Exception {
        final UcmdbClient ucmdbClient = new UcmdbClient(config);
        return testConnection(ucmdbClient, config);
    }
    
    public static UcmdbClient getUcmdbClient(final String server) throws Exception {
        final UcmdbClient uc = UcmdbClient.clientPool.get(server);
        if (uc != null) {
            return uc;
        }
        final ServerConfig config = ServerConfigManager.getInstance().getDefaultServerConfig((Project)null, server);
        if (config == null) {
            throw new IllegalArgumentException("Unknown server:" + server + ", please save the setting first.");
        }
        final UcmdbClient ucmdbClient = new UcmdbClient(config);
        return testConnection(ucmdbClient, config);
    }
    
    private static UcmdbClient testConnection(UcmdbClient client, final ServerConfig config) throws Exception {
        if (!client.isConnect() || !validateConnectivity(client)) {
            client.connect();
            final String fullServerVersion = client.getUCMDBVersion().getFullServerVersion();
            final String[] split = fullServerVersion.split("\\.");
            final int major = Integer.parseInt(split[0]);
            final int minor = Integer.parseInt(split[1]);
            if (major >= 10 && minor >= 20) {
                client = (UcmdbClient)new UcmdbClientNew(config);
                client.connect();
            }
        }
        return client;
    }
    
    private static boolean validateConnectivity(final UcmdbClient client) {
        try {
            final UcmdbVersion ucmdbVersion = client.ucmdbService.getUcmdbVersion();
            return ucmdbVersion != null;
        }
        catch (Exception e) {
            e.printStackTrace();
            return client.isConnect = false;
        }
    }
    
    public UcmdbVersion getUCMDBVersion() {
        return this.ucmdbService.getUcmdbVersion();
    }
    
    private static void validateConfig(final Project project) {
        final ServerConfig serverConfig = ServerConfigManager.getInstance().getDefaultServerConfig(project);
        if (!UcmdbClient.currentClient.serverConfig.equals((Object)serverConfig)) {
            UcmdbClient.currentClient = null;
        }
    }
    
    public static void invalidateClient() {
        UcmdbClient.currentClient = null;
    }
    
    public boolean isConnect() {
        return this.isConnect;
    }
    
    public boolean connect() throws Exception {
        if (!this.isConnect) {
            System.out.println("Begin connect...");
            this.doConnect();
            System.out.println("Connected.");
        }
        return this.isConnect;
    }
    
    private void doConnect() throws Exception {
        UcmdbServiceProvider provider = null;
        try {
            System.setProperty("ignoreServerCertValidation", "true");
            provider = UcmdbServiceFactory.getServiceProvider(this.serverConfig.getProtocol(), this.serverConfig.getServer(), this.serverConfig.getPort());
            final Credentials credentials = provider.createCredentials(this.serverConfig.getUsername(), DesUtil.decrypt(this.serverConfig.getPassword()));
            final ClientContext clientContext = provider.createClientContext("Example");
            final UcmdbService ucmdbService = provider.connect(credentials, clientContext);
            System.out.println(ucmdbService);
            if (ucmdbService != null) {
                this.ucmdbService = ucmdbService;
                this.isConnect = true;
            }
        }
        catch (Exception e) {
            throw e;
        }
    }
    
    public void setResourceContent(final DiscoveryResType type, final String name, final byte[] content) throws Exception {
        final DDMConfigurationService ddmc = this.ucmdbService.getDDMConfigurationService();
        ddmc.updateResourceData(type, name, content);
    }
    
    public byte[] getResourceContent(final DiscoveryResType type, final String name) throws Exception {
        final DDMConfigurationService ddmc = this.ucmdbService.getDDMConfigurationService();
        return ddmc.getResourceData(type, name);
    }
    
    public Collection<DiscoveryResData> listResources(final DiscoveryResType type) {
        final DDMConfigurationService ddmc = this.ucmdbService.getDDMConfigurationService();
        return (Collection<DiscoveryResData>)ddmc.listResources(type);
    }
    
    public DiscoveryResData getResources(final DiscoveryResType type, final String name) {
        final DDMConfigurationService ddmc = this.ucmdbService.getDDMConfigurationService();
        final DiscoveryResType x = DiscoveryResType.values()[type.ordinal()];
        return ddmc.getResource(x, name);
    }
    
    public void deployPackage(final File file) throws IOException {
        this.ucmdbService.getResourceManagementService().deployPackage(file);
    }
    
    public void deployPackage(final String packageName, final InputStream packageContent) throws IOException {
        this.ucmdbService.getResourceManagementService().deployPackage(packageName, packageContent);
    }
    
    public void startJob(final String job) {
        final DDMManagementService ddmManagementService = this.ucmdbService.getDDMManagementService();
        final ArrayList<String> jobs = new ArrayList<String>();
        jobs.add(job);
        ddmManagementService.activateJobs(new HashSet((Collection<? extends E>)jobs));
    }
    
    public void stopJob(final String job) {
        final DDMManagementService ddmManagementService = this.ucmdbService.getDDMManagementService();
        final ArrayList<String> jobs = new ArrayList<String>();
        jobs.add(job);
        ddmManagementService.deactivateJobs(new HashSet((Collection<? extends E>)jobs));
    }
    
    public static void refreshPool() {
        final Collection<ServerConfig> allServerConfig = (Collection<ServerConfig>)ServerConfigManager.getInstance().getAllServerConfig((Project)null);
        final String message = "RefreshPool" + allServerConfig.toString();
        System.out.println(message);
        for (final ServerConfig sc : allServerConfig) {
            try {
                final UcmdbClient ucmdbClient = getUcmdbClient(sc);
                UcmdbClient.clientPool.put(sc.getServer(), ucmdbClient);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(final String[] args) throws Exception {
        UcmdbServiceProvider provider = null;
        try {
            provider = UcmdbServiceFactory.getServiceProvider("example", 8080);
            final Credentials credentials = provider.createCredentials("userName", "password");
            final ClientContext clientContext = provider.createClientContext("Example");
            final UcmdbService ucmdbService = provider.connect(credentials, clientContext);
            System.out.println(ucmdbService);
            final ResourceManagementService resourceManagementService = ucmdbService.getResourceManagementService();
            System.out.println(resourceManagementService);
            final Method m = resourceManagementService.getClass().getMethod("getRevisions", String.class);
            final Object invoke = m.invoke(resourceManagementService, "dns.py");
            System.out.println(invoke);
            final Map[] mx = (Map[])invoke;
            for (int i = 0; i < mx.length; ++i) {
                System.out.println(mx[i].get("revision"));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    public Map<String, Object>[] getHistory(final String name) throws Exception {
        final ResourceManagementService resourceManagementService = this.ucmdbService.getResourceManagementService();
        final Method m = resourceManagementService.getClass().getMethod("getRevisions", String.class);
        final Object invoke = m.invoke(resourceManagementService, name);
        return (Map<String, Object>[])invoke;
    }
    
    public byte[] getRevisionContent(final String resourceName, final long revision) throws Exception {
        final ResourceManagementService resourceManagementService = this.ucmdbService.getResourceManagementService();
        final Method m = resourceManagementService.getClass().getMethod("getRevisionContent", String.class, Long.TYPE);
        final Object invoke = m.invoke(resourceManagementService, resourceName, revision);
        return (byte[])invoke;
    }
    
    static {
        UcmdbClient.clientPool = new HashMap<String, UcmdbClient>();
    }
}