/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.util.HashMap;
import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import com.intellij.openapi.components.ServiceManager;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.components.Storage;
import com.intellij.openapi.components.State;
import com.intellij.openapi.components.PersistentStateComponent;

@com.intellij.openapi.components.State(name = "UDCSettings", storages = { @Storage(file = "$APP_CONFIG$/UDC.xml") })
public class UDCSettings implements PersistentStateComponent<State>
{
    State myState;
    
    public UDCSettings() {
        this.myState = new State();
    }
    
    @NotNull
    public State getState() {
        final State myState = this.myState;
        if (myState == null) {
            throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/UDCSettings", "getState"));
        }
        return myState;
    }
    
    public void loadState(final State state) {
        if (state != null) {
            this.myState = state;
        }
    }
    
    public static UDCSettings getSettings(final Project project) {
        if (project == null) {
            return (UDCSettings)ServiceManager.getService((Class)UDCSettings.class);
        }
        return (UDCSettings)ServiceManager.getService(project, (Class)UDCSettings.class);
    }
    
    public static UDCSettings getSettings() {
        return (UDCSettings)ServiceManager.getService((Class)UDCSettings.class);
    }
    
    public static ServerSetting getServerSetting(final Project project, final String name) {
        return getSettings(project).getState().serverConfigs.get(name);
    }
    
    public static ServerSetting getDefaultServerSetting(final Project project) {
        final State state = getSettings(project).getState();
        if (state.defaultServer != null) {
            return state.serverConfigs.get(state.defaultServer);
        }
        final Iterator<ServerSetting> iterator = state.serverConfigs.values().iterator();
        if (iterator.hasNext()) {
            return iterator.next();
        }
        return null;
    }
    
    public static Collection<ServerSetting> getAllSettings(final Project project) {
        return getSettings(project).getState().serverConfigs.values();
    }
    
    public static class State
    {
        public String defaultServer;
        public Map<String, ServerSetting> serverConfigs;
        
        public State() {
            this.serverConfigs = new HashMap<String, ServerSetting>();
        }
    }
    
    public static class ServerSetting
    {
        String server;
        int port;
        String username;
        String password;
        String label;
        String protocol;
        
        public String getServer() {
            return this.server;
        }
        
        public int getPort() {
            return this.port;
        }
        
        public String getUsername() {
            return this.username;
        }
        
        public String getPassword() throws Exception {
            return this.password;
        }
        
        public void setServer(final String server) {
            this.server = server;
        }
        
        public void setPort(final int port) {
            this.port = port;
        }
        
        public void setUsername(final String username) {
            this.username = username;
        }
        
        public void setPassword(final String password) throws Exception {
            this.password = password;
        }
        
        public String getProtocol() {
            return this.protocol;
        }
        
        public void setProtocol(final String protocol) {
            this.protocol = protocol;
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || this.getClass() != o.getClass()) {
                return false;
            }
            final ServerSetting that = (ServerSetting)o;
            if (this.port != that.port) {
                return false;
            }
            if (this.password != null) {
                if (this.password.equals(that.password)) {
                    return this.server.equals(that.server) && this.username.equals(that.username) && this.label.equals(that.label) && this.protocol.equals(that.protocol);
                }
            }
            else if (that.password == null) {
                return this.server.equals(that.server) && this.username.equals(that.username) && this.label.equals(that.label) && this.protocol.equals(that.protocol);
            }
            return false;
        }
        
        @Override
        public int hashCode() {
            return this.server.hashCode();
        }
        
        public String getLabel() {
            return this.label;
        }
        
        public void setLabel(final String label) {
            this.label = label;
        }
        
        @Override
        public String toString() {
            return this.label + " (" + this.server + ")";
        }
    }
}