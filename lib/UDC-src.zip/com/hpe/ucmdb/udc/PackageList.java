/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import javax.swing.JComponent;
import com.intellij.uiDesigner.core.Spacer;
import java.awt.Dimension;
import com.intellij.uiDesigner.core.GridConstraints;
import java.awt.LayoutManager;
import com.intellij.uiDesigner.core.GridLayoutManager;
import java.awt.Insets;
import java.awt.AWTEvent;
import java.awt.Window;
import javax.swing.KeyStroke;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import com.intellij.openapi.ui.Messages;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.TableColumn;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.Iterator;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import com.hpe.ucmdb.udc.viewer.CheckTableModle;
import java.util.Vector;
import java.util.Comparator;
import java.util.Collections;
import com.hpe.ucmdb.udc.viewer.Test;
import java.util.Arrays;
import java.util.ArrayList;
import java.awt.Container;
import java.awt.Component;
import java.util.HashSet;
import com.hp.ucmdb.api.discovery.types.DiscoveryResData;
import java.util.List;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import java.util.Map;
import com.hpe.ucmdb.udc.model.PackageTable;
import java.util.Set;
import com.intellij.openapi.project.Project;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JDialog;

public class PackageList extends JDialog
{
    private JPanel contentPane;
    private JButton buttonDownload;
    private JButton buttonCancel;
    private JTable table;
    private JTextField searchField;
    private JButton selectAllButton;
    private JButton unselectAllButton;
    private JPanel JP1;
    private JScrollPane JScroll;
    private Project project;
    private String[] chosenPackages;
    private Set<PackageTable> selected;
    
    public PackageList(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup) {
        this.$$$setupUI$$$();
        this.selected = new HashSet<PackageTable>();
        this.setLocationRelativeTo(null);
        this.setContentPane(this.contentPane);
        this.setTitle("Package List");
        this.setModal(true);
        this.setBounds(500, 220, 600, 500);
        final String[] list = resGroup.keySet().toArray(new String[0]);
        List<String> l = new ArrayList<String>();
        l = Arrays.asList(list);
        Collections.sort(l, (Comparator<? super String>)new Test());
        final String[] t = l.toArray(new String[l.size()]);
        final List<PackageTable> data = this.getData(t);
        final Vector headerNames = new Vector();
        headerNames.add("Package Name");
        headerNames.add("");
        if (this.selected.size() != 0) {
            for (final PackageTable pt : this.selected) {
                for (final PackageTable packageName : data) {
                    if (pt.getPackageName().equals(packageName.getPackageName())) {
                        packageName.setSelected(true);
                    }
                }
            }
        }
        final Vector v = new Vector();
        final Iterator<PackageTable> it = data.iterator();
        while (it.hasNext()) {
            final Vector v2 = new Vector();
            final PackageTable py = it.next();
            v2.add(py.getPackageName());
            v2.add(py.isSelected());
            v.add(v2);
        }
        final CheckTableModle tableModel = new CheckTableModle(v, headerNames);
        this.table.setModel((TableModel)tableModel);
        final TableColumn firsetColumn = this.table.getColumnModel().getColumn(1);
        firsetColumn.setPreferredWidth(100);
        firsetColumn.setMaxWidth(100);
        firsetColumn.setMinWidth(100);
        this.table.setShowGrid(false);
        this.table.setRowHeight(22);
        this.table.setRowMargin(2);
        this.getRootPane().setDefaultButton(this.buttonDownload);
        this.table.getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(final TableModelEvent e) {
                if (e.getLastRow() != -1 && e.getColumn() != -1) {
                    if (PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn())) {
                        final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                        if (!selectedPackageName.equals("Package Name")) {
                            final PackageTable s = new PackageTable(selectedPackageName, true);
                            PackageList.this.selected.add(s);
                        }
                    }
                    else {
                        final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                        PackageTable remove = null;
                        for (final PackageTable pt : PackageList.this.selected) {
                            if (pt.getPackageName().equals(selectedPackageName)) {
                                remove = pt;
                            }
                        }
                        PackageList.this.selected.remove(remove);
                    }
                }
            }
        });
        this.searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(final DocumentEvent e) {
                final String query = PackageList.this.searchField.getText();
                final List<String> queryResults = new ArrayList<String>();
                for (final String q : t) {
                    if (q.toLowerCase().contains(query.toLowerCase())) {
                        queryResults.add(q);
                    }
                }
                Collections.sort(queryResults, (Comparator<? super String>)new Test());
                final String[] t1 = queryResults.toArray(new String[queryResults.size()]);
                final Vector data = this.getData(t1);
                PackageList.this.initTable(data, tableModel);
                final TableColumn firsetColumn = PackageList.this.table.getColumnModel().getColumn(1);
                firsetColumn.setPreferredWidth(100);
                firsetColumn.setMaxWidth(100);
                firsetColumn.setMinWidth(100);
                PackageList.this.table.setShowGrid(false);
                PackageList.this.getRootPane().setDefaultButton(PackageList.this.buttonDownload);
                PackageList.this.table.getModel().addTableModelListener(new TableModelListener() {
                    @Override
                    public void tableChanged(final TableModelEvent e) {
                        if (e.getLastRow() != -1 && e.getColumn() != -1) {
                            if (PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn())) {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                if (!selectedPackageName.equals("Package Name")) {
                                    final PackageTable s = new PackageTable(selectedPackageName, true);
                                    PackageList.this.selected.add(s);
                                }
                            }
                            else {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                PackageTable remove = null;
                                for (final PackageTable pt : PackageList.this.selected) {
                                    if (pt.getPackageName().equals(selectedPackageName)) {
                                        remove = pt;
                                    }
                                }
                                PackageList.this.selected.remove(remove);
                            }
                        }
                    }
                });
            }
            
            public Vector getData(final String[] packageNames) {
                final Vector<PackageTable> data = new Vector<PackageTable>();
                for (String packageName : packageNames) {
                    if (packageName.endsWith(".zip")) {
                        packageName = packageName.substring(0, packageName.length() - 4);
                    }
                    final PackageTable pt = new PackageTable(packageName, false);
                    data.add(pt);
                }
                return data;
            }
            
            @Override
            public void removeUpdate(final DocumentEvent e) {
                final String query = PackageList.this.searchField.getText();
                final List<String> queryResults = new ArrayList<String>();
                for (final String q : t) {
                    if (q.toLowerCase().contains(query.toLowerCase())) {
                        queryResults.add(q);
                    }
                }
                Collections.sort(queryResults, (Comparator<? super String>)new Test());
                final String[] t1 = queryResults.toArray(new String[queryResults.size()]);
                final Vector data = this.getData(t1);
                PackageList.this.initTable(data, tableModel);
                final TableColumn firsetColumn = PackageList.this.table.getColumnModel().getColumn(1);
                firsetColumn.setPreferredWidth(100);
                firsetColumn.setMaxWidth(100);
                firsetColumn.setMinWidth(100);
                PackageList.this.table.setShowGrid(false);
                PackageList.this.getRootPane().setDefaultButton(PackageList.this.buttonDownload);
                PackageList.this.table.getModel().addTableModelListener(new TableModelListener() {
                    @Override
                    public void tableChanged(final TableModelEvent e) {
                        if (e.getLastRow() != -1 && e.getColumn() != -1) {
                            if (PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn())) {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                if (!selectedPackageName.equals("Package Name")) {
                                    final PackageTable s = new PackageTable(selectedPackageName, true);
                                    PackageList.this.selected.add(s);
                                }
                            }
                            else {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                PackageTable remove = null;
                                for (final PackageTable pt : PackageList.this.selected) {
                                    if (pt.getPackageName().equals(selectedPackageName)) {
                                        remove = pt;
                                    }
                                }
                                PackageList.this.selected.remove(remove);
                            }
                        }
                    }
                });
            }
            
            @Override
            public void changedUpdate(final DocumentEvent e) {
                final String query = PackageList.this.searchField.getText();
                final List<String> queryResults = new ArrayList<String>();
                for (final String q : t) {
                    if (q.toLowerCase().contains(query.toLowerCase())) {
                        queryResults.add(q);
                    }
                }
                Collections.sort(queryResults, (Comparator<? super String>)new Test());
                final String[] t1 = queryResults.toArray(new String[queryResults.size()]);
                final Vector data = this.getData(t1);
                PackageList.this.initTable(data, tableModel);
                final TableColumn firsetColumn = PackageList.this.table.getColumnModel().getColumn(1);
                firsetColumn.setPreferredWidth(100);
                firsetColumn.setMaxWidth(100);
                firsetColumn.setMinWidth(100);
                PackageList.this.table.setShowGrid(false);
                PackageList.this.getRootPane().setDefaultButton(PackageList.this.buttonDownload);
                PackageList.this.table.getModel().addTableModelListener(new TableModelListener() {
                    @Override
                    public void tableChanged(final TableModelEvent e) {
                        if (e.getLastRow() != -1 && e.getColumn() != -1) {
                            if (PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn())) {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                if (!selectedPackageName.equals("Package Name")) {
                                    final PackageTable s = new PackageTable(selectedPackageName, true);
                                    PackageList.this.selected.add(s);
                                }
                            }
                            else {
                                final String selectedPackageName = PackageList.this.table.getValueAt(e.getLastRow(), e.getColumn() - 1).toString();
                                PackageTable remove = null;
                                for (final PackageTable pt : PackageList.this.selected) {
                                    if (pt.getPackageName().equals(selectedPackageName)) {
                                        remove = pt;
                                    }
                                }
                                PackageList.this.selected.remove(remove);
                            }
                        }
                    }
                });
            }
        });
        this.buttonDownload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final Set<String> packageList = new HashSet<String>();
                for (final PackageTable pt : PackageList.this.selected) {
                    if (!packageList.contains(pt.getPackageName())) {
                        packageList.add(pt.getPackageName());
                    }
                }
                if (packageList.isEmpty()) {
                    Messages.showMessageDialog(PackageList.this.project, "No package has been chosen,please choose a package", "Information", Messages.getInformationIcon());
                    PackageList.this.chosenPackages = packageList.toArray(new String[0]);
                }
                else {
                    PackageList.this.chosenPackages = packageList.toArray(new String[0]);
                    PackageList.this.dispose();
                }
            }
        });
        this.selectAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final int rowC = tableModel.getRowCount();
                final Iterator<PackageTable> it = PackageList.this.selected.iterator();
                final Set<String> selectedS = new HashSet<String>();
                while (it.hasNext()) {
                    selectedS.add(it.next().getPackageName());
                }
                if (rowC > 0) {
                    for (int i = 0; i < rowC; ++i) {
                        if (!selectedS.contains(tableModel.getValueAt(i, 0).toString())) {
                            tableModel.setValueAt((Object)true, i, 1);
                        }
                    }
                }
            }
        });
        this.unselectAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final int rowC = tableModel.getRowCount();
                if (rowC > 0) {
                    for (int i = 0; i < rowC; ++i) {
                        tableModel.setValueAt((Object)false, i, 1);
                    }
                }
            }
        });
        this.buttonCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                try {
                    PackageList.this.quit();
                }
                catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        this.setDefaultCloseOperation(0);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                PackageList.this.onCancel();
            }
        });
        this.contentPane.registerKeyboardAction(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                PackageList.this.onCancel();
            }
        }, KeyStroke.getKeyStroke(27, 0), 1);
    }
    
    private void onOK() {
        this.dispose();
    }
    
    private void onCancel() {
        this.dispose();
    }
    
    public void initTable(final List<PackageTable> data, final CheckTableModle tableModel) {
        if (this.selected.size() != 0) {
            for (final PackageTable pt : this.selected) {
                for (final PackageTable packageName : data) {
                    if (pt.getPackageName().equals(packageName.getPackageName())) {
                        packageName.setSelected(true);
                    }
                }
            }
        }
        for (int i = tableModel.getRowCount() - 1; i >= 0; --i) {
            tableModel.removeRow(i);
        }
        for (int i = 0; i < data.size(); ++i) {
            final Vector v1 = new Vector();
            v1.add(data.get(i).getPackageName());
            v1.add(data.get(i).isSelected());
            tableModel.addRow(v1);
        }
    }
    
    public List<PackageTable> getData(final String[] packageNames) {
        final List<PackageTable> data = new ArrayList<PackageTable>();
        for (String packageName : packageNames) {
            if (packageName.endsWith(".zip")) {
                packageName = packageName.substring(0, packageName.length() - 4);
            }
            final PackageTable pt = new PackageTable(packageName, false);
            data.add(pt);
        }
        return data;
    }
    
    public String[] getChosenPackages() {
        return this.chosenPackages;
    }
    
    public void quit() throws Exception {
        this.dispatchEvent(new WindowEvent(this, 201));
    }
    
    private  void $$$setupUI$$$() {
        final JPanel contentPane = new JPanel();
        (this.contentPane = contentPane).setLayout((LayoutManager)new GridLayoutManager(3, 1, new Insets(10, 10, 10, 10), -1, -1, false, false));
        final JPanel panel = new JPanel();
        panel.setLayout((LayoutManager)new GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel, new GridConstraints(2, 0, 1, 1, 0, 3, 3, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        panel.add((Component)new Spacer(), new GridConstraints(0, 0, 1, 1, 0, 1, 6, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel2 = new JPanel();
        panel2.setLayout((LayoutManager)new GridLayoutManager(1, 4, new Insets(0, 0, 0, 0), -1, -1, false, false));
        panel.add(panel2, new GridConstraints(0, 1, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton buttonDownload = new JButton();
        (this.buttonDownload = buttonDownload).setText("Download");
        panel2.add(buttonDownload, new GridConstraints(0, 2, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton buttonCancel = new JButton();
        (this.buttonCancel = buttonCancel).setText("Cancel");
        panel2.add(buttonCancel, new GridConstraints(0, 3, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton selectAllButton = new JButton();
        (this.selectAllButton = selectAllButton).setText("Select All");
        panel2.add(selectAllButton, new GridConstraints(0, 0, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton unselectAllButton = new JButton();
        (this.unselectAllButton = unselectAllButton).setText("Unselect All");
        panel2.add(unselectAllButton, new GridConstraints(0, 1, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel jp1 = new JPanel();
        (this.JP1 = jp1).setLayout((LayoutManager)new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(jp1, new GridConstraints(1, 0, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JScrollPane jScroll = new JScrollPane();
        (this.JScroll = jScroll).setVerticalScrollBarPolicy(22);
        jp1.add(jScroll, new GridConstraints(0, 0, 1, 1, 0, 3, 7, 7, (Dimension)null, (Dimension)null, (Dimension)null));
        jScroll.setViewportView(this.table = new JTable());
        final JPanel panel3 = new JPanel();
        panel3.setLayout((LayoutManager)new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel3, new GridConstraints(0, 0, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        panel3.add(this.searchField = new JTextField(), new GridConstraints(0, 0, 1, 1, 8, 1, 6, 0, (Dimension)null, new Dimension(150, -1), (Dimension)null));
    }
}