/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import com.intellij.uiDesigner.core.Spacer;
import java.awt.Dimension;
import com.intellij.uiDesigner.core.GridConstraints;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import com.intellij.uiDesigner.core.GridLayoutManager;
import java.awt.Insets;
import java.util.Arrays;
import java.util.HashMap;
import javax.swing.JComponent;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Nls;
import java.awt.Container;
import java.awt.CardLayout;
import java.util.concurrent.ExecutionException;
import com.intellij.openapi.ui.Messages;
import javax.swing.SwingWorker;
import javax.swing.JProgressBar;
import javax.swing.JDialog;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;
import javax.swing.ListModel;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.openapi.application.ApplicationManager;
import java.util.Iterator;
import java.util.Map;
import com.intellij.openapi.project.Project;
import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JLabel;
import com.intellij.openapi.options.Configurable;

public class UDCConfigUI implements Configurable
{
    public static final String SETTING_NAME = "UDC Configuration";
    private JLabel defaultServerLabel;
    private JButton newButton;
    private JButton deleteButton;
    private JButton setAsDefaultButton;
    private JButton connectButton;
    private JList<ServerListItemWrapper> serverList;
    private JPanel mainPanel;
    private JPanel formPanel;
    private String EMPTY_PANEL;
    private final DefaultListModel<ServerListItemWrapper> serverListModel;
    private Project project;
    
    public UDCConfigUI() {
        this(null);
    }
    
    public DefaultListModel<ServerListItemWrapper> getSeverList() {
        final Map<String, UDCSettings.ServerSetting> serverConfigs = (Map<String, UDCSettings.ServerSetting>)UDCSettings.getSettings(this.project).getState().serverConfigs;
        for (final String label : serverConfigs.keySet()) {
            final ServerConfigForm serverConfigForm = new ServerConfigForm();
            try {
                serverConfigForm.setData((UDCSettings.ServerSetting)serverConfigs.get(label));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            this.serverListModel.addElement(new ServerListItemWrapper(serverConfigForm));
        }
        return this.serverListModel;
    }
    
    public void setDefault() {
        final ServerConfigForm serverConfigForm = this.serverListModel.getElementAt(0).serverConfigForm;
        final UDCSettings.ServerSetting serverSetting = new UDCSettings.ServerSetting();
        try {
            serverConfigForm.getData(serverSetting);
            UDCSettings.getSettings(this.project).getState().defaultServer = serverSetting.getLabel();
            if (serverSetting.getLabel() != null) {
                this.defaultServerLabel.setText("Default:  " + serverSetting.getLabel());
            }
            else {
                this.defaultServerLabel.setText("Default:  " + serverSetting.getServer());
            }
            ((DefaultServerChangeListener)ApplicationManager.getApplication().getMessageBus().syncPublisher(DefaultServerChangeListener.TOPIC)).defaultServerChanged();
        }
        catch (ConfigurationException e1) {
            e1.printStackTrace();
        }
        catch (Exception e2) {
            e2.printStackTrace();
        }
    }
    
    public UDCConfigUI(final Project project) {
        this.EMPTY_PANEL = "EMPTY_PANEL";
        this.project = project;
        this.$$$setupUI$$$();
        this.serverListModel = new DefaultListModel<ServerListItemWrapper>();
        this.serverList.setModel(this.serverListModel);
        this.serverList.setSelectionMode(0);
        this.formPanel.add(new JPanel(), this.EMPTY_PANEL);
        final String defaultServer = UDCSettings.getSettings(project).getState().defaultServer;
        this.newButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final ServerConfigForm serverConfigPanel = new ServerConfigForm();
                final ServerListItemWrapper element = new ServerListItemWrapper(serverConfigPanel);
                UDCConfigUI.this.serverListModel.addElement(element);
                UDCConfigUI.this.serverList.setSelectedValue(element, true);
                UDCConfigUI.this.formPanel.add((Component)serverConfigPanel, serverConfigPanel.getId());
                UDCConfigUI.this.selectForm();
            }
        });
        this.deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final int selectedIndex = UDCConfigUI.this.serverList.getSelectedIndex();
                final int i = UDCConfigUI.this.confirmDelete(project);
                if (i == 0 && selectedIndex != -1) {
                    if (UDCConfigUI.this.serverListModel.get(selectedIndex).toString().equals(UDCSettings.getSettings(project).getState().defaultServer)) {
                        UDCConfigUI.this.defaultServerLabel.setText("Default:  NA");
                        UDCSettings.getSettings(UDCConfigUI.this.project).getState().defaultServer = "NA";
                    }
                    UDCConfigUI.this.serverListModel.remove(selectedIndex);
                }
            }
        });
        this.serverList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(final ListSelectionEvent e) {
                UDCConfigUI.this.selectForm();
            }
        });
        this.setAsDefaultButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final ServerConfigForm serverConfigForm = UDCConfigUI.this.serverList.getSelectedValue().serverConfigForm;
                final UDCSettings.ServerSetting serverSetting = new UDCSettings.ServerSetting();
                try {
                    serverConfigForm.getData(serverSetting);
                    UDCSettings.getSettings(UDCConfigUI.this.project).getState().defaultServer = serverSetting.getLabel();
                    if (serverSetting.getLabel() != null) {
                        UDCConfigUI.this.defaultServerLabel.setText("Default:  " + serverSetting.getLabel());
                    }
                    else {
                        UDCConfigUI.this.defaultServerLabel.setText("Default:  " + serverSetting.getServer());
                    }
                    ((DefaultServerChangeListener)ApplicationManager.getApplication().getMessageBus().syncPublisher(DefaultServerChangeListener.TOPIC)).defaultServerChanged();
                }
                catch (ConfigurationException e2) {
                    e2.printStackTrace();
                }
                catch (Exception e3) {
                    e3.printStackTrace();
                }
            }
        });
        this.connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final ServerConfigForm serverConfigForm = UDCConfigUI.this.serverList.getSelectedValue().serverConfigForm;
                final UDCSettings.ServerSetting serverSetting = new UDCSettings.ServerSetting();
                try {
                    serverConfigForm.getData(serverSetting);
                    final ServerConfig serverConfig = ServerConfigManager.createServerConfig(serverSetting);
                    final JDialog messageDialog = new JDialog();
                    messageDialog.setAlwaysOnTop(true);
                    messageDialog.setLocationRelativeTo(null);
                    messageDialog.setUndecorated(true);
                    final JProgressBar progressBar = new JProgressBar();
                    progressBar.setIndeterminate(true);
                    messageDialog.add(progressBar);
                    messageDialog.pack();
                    progressBar.setIndeterminate(true);
                    progressBar.setString("Test Connection:" + serverConfig.getServer());
                    messageDialog.setVisible(true);
                    final SwingWorker sw = new SwingWorker() {
                        @Override
                        protected Object doInBackground() throws Exception {
                            try {
                                UcmdbClient.getUcmdbClient(serverConfig);
                            }
                            catch (Exception e1) {
                                return false;
                            }
                            return true;
                        }
                        
                        @Override
                        protected void done() {
                            messageDialog.setVisible(false);
                            try {
                                if (this.get()) {
                                    Messages.showInfoMessage(project, "Connected to " + serverConfig.getServer(), "Info");
                                }
                                else {
                                    Messages.showErrorDialog(project, "Failed to connect to " + serverConfig.getServer(), "Error");
                                }
                            }
                            catch (InterruptedException e1) {
                                e1.printStackTrace();
                            }
                            catch (ExecutionException e2) {
                                e2.printStackTrace();
                            }
                        }
                    };
                    sw.execute();
                }
                catch (Exception e2) {
                    Messages.showErrorDialog(project, e2.getMessage(), "Error");
                    throw new RuntimeException(e2);
                }
            }
        });
    }
    
    private void selectForm() {
        final ServerListItemWrapper selectedValue = this.serverList.getSelectedValue();
        if (selectedValue != null) {
            final String constraint = selectedValue.serverConfigForm.getId();
            ((CardLayout)this.formPanel.getLayout()).show(this.formPanel, constraint);
        }
        else {
            ((CardLayout)this.formPanel.getLayout()).show(this.formPanel, this.EMPTY_PANEL);
        }
    }
    
    private int confirmDelete(final Project project) {
        return Messages.showOkCancelDialog(project, "Are you sure to delete this server ?", "Delete", "Yes", "No", Messages.getInformationIcon());
    }
    
    private void alert(final Project project) {
        Messages.showMessageDialog(project, "The server has been deleted successfully", "Information", Messages.getInformationIcon());
    }
    
    @Nls
    public String getDisplayName() {
        return "UDC Configuration";
    }
    
    @Nullable
    public String getHelpTopic() {
        return null;
    }
    
    @Nullable
    public JComponent createComponent() {
        return this.mainPanel;
    }
    
    public boolean isModified() {
        final Map<String, UDCSettings.ServerSetting> serverConfigs = (Map<String, UDCSettings.ServerSetting>)UDCSettings.getSettings(this.project).getState().serverConfigs;
        final Map<String, UDCSettings.ServerSetting> newConfig = new HashMap<String, UDCSettings.ServerSetting>();
        for (int i = 0; i < this.serverListModel.size(); ++i) {
            final ServerConfigForm form = this.serverListModel.get(i).serverConfigForm;
            final UDCSettings.ServerSetting serverSetting = new UDCSettings.ServerSetting();
            try {
                form.getDataForModify(serverSetting);
            }
            catch (ConfigurationException e) {
                e.printStackTrace();
            }
            catch (Exception e2) {
                e2.printStackTrace();
            }
            newConfig.put(serverSetting.getLabel(), serverSetting);
        }
        return !Arrays.equals(serverConfigs.values().toArray(), newConfig.values().toArray());
    }
    
    public void apply() throws ConfigurationException {
        final Map<String, UDCSettings.ServerSetting> serverConfigs = (Map<String, UDCSettings.ServerSetting>)UDCSettings.getSettings(this.project).getState().serverConfigs;
        serverConfigs.clear();
        String firstServer = null;
        for (int i = 0; i < this.serverListModel.size(); ++i) {
            final ServerConfigForm form = this.serverListModel.get(i).serverConfigForm;
            final UDCSettings.ServerSetting serverSetting = new UDCSettings.ServerSetting();
            try {
                final boolean isValid = form.getData(serverSetting);
                if (!isValid) {
                    continue;
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            serverConfigs.put(serverSetting.getLabel(), serverSetting);
            if (firstServer == null) {
                firstServer = serverSetting.server;
            }
        }
        final String defaultServer = UDCSettings.getSettings(this.project).getState().defaultServer;
        if (defaultServer == null && !serverConfigs.isEmpty()) {
            UDCSettings.getSettings(this.project).getState().defaultServer = firstServer;
        }
        ((DefaultServerChangeListener)ApplicationManager.getApplication().getMessageBus().syncPublisher(DefaultServerChangeListener.TOPIC)).defaultServerChanged();
    }
    
    public void reset() {
        this.serverListModel.removeAllElements();
        this.formPanel.removeAll();
        final Map<String, UDCSettings.ServerSetting> serverConfigs = (Map<String, UDCSettings.ServerSetting>)UDCSettings.getSettings(this.project).getState().serverConfigs;
        for (final String label : serverConfigs.keySet()) {
            final ServerConfigForm serverConfigForm = new ServerConfigForm();
            try {
                serverConfigForm.setData((UDCSettings.ServerSetting)serverConfigs.get(label));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            this.serverListModel.addElement(new ServerListItemWrapper(serverConfigForm));
            this.formPanel.add((Component)serverConfigForm, serverConfigForm.getId());
        }
        if (this.serverListModel.getSize() > 0) {
            this.serverList.setSelectedIndex(0);
        }
        final String defaultServer = UDCSettings.getSettings(this.project).getState().defaultServer;
        if (!this.serverListModel.toString().contains(defaultServer)) {
            this.defaultServerLabel.setText("Default:  NA");
        }
        else {
            this.defaultServerLabel.setText("Default:   " + defaultServer);
        }
    }
    
    public void disposeUIResources() {
    }
    
    public String getModelList() {
        return this.serverListModel.toString();
    }
    
    public static void main(final String[] args) {
        final JDialog messageDialog = new JDialog();
        messageDialog.setAlwaysOnTop(true);
        messageDialog.setLocationRelativeTo(null);
        messageDialog.setUndecorated(true);
        final JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        messageDialog.add(progressBar);
        messageDialog.pack();
        messageDialog.setVisible(true);
    }
    
    private  void $$$setupUI$$$() {
        final JPanel mainPanel = new JPanel();
        (this.mainPanel = mainPanel).setLayout((LayoutManager)new GridLayoutManager(2, 3, new Insets(0, 0, 0, 0), -1, -1, false, false));
        final JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(1, 5, 5));
        mainPanel.add(panel, new GridConstraints(0, 1, 1, 2, 0, 0, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton newButton = new JButton();
        (this.newButton = newButton).setText("New");
        panel.add(newButton);
        final JButton deleteButton = new JButton();
        (this.deleteButton = deleteButton).setText("Delete");
        panel.add(deleteButton);
        final JButton setAsDefaultButton = new JButton();
        (this.setAsDefaultButton = setAsDefaultButton).setText("Set as Default");
        panel.add(setAsDefaultButton);
        final JButton connectButton = new JButton();
        (this.connectButton = connectButton).setText("Test Connect");
        panel.add(connectButton);
        mainPanel.add((Component)new Spacer(), new GridConstraints(1, 2, 1, 1, 0, 2, 1, 6, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel2 = new JPanel();
        panel2.setLayout((LayoutManager)new GridLayoutManager(2, 2, new Insets(0, 0, 0, 0), -1, -1, false, false));
        mainPanel.add(panel2, new GridConstraints(1, 0, 1, 2, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        panel2.add((Component)new Spacer(), new GridConstraints(1, 1, 1, 1, 0, 1, 6, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel formPanel = new JPanel();
        (this.formPanel = formPanel).setLayout(new CardLayout(0, 0));
        panel2.add(formPanel, new GridConstraints(0, 1, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JList<ServerListItemWrapper> serverList = new JList<ServerListItemWrapper>();
        (this.serverList = serverList).setModel(new DefaultListModel<ServerListItemWrapper>());
        panel2.add(serverList, new GridConstraints(0, 0, 2, 1, 0, 3, 2, 6, (Dimension)null, new Dimension(150, 50), (Dimension)null));
        final JLabel defaultServerLabel = new JLabel();
        (this.defaultServerLabel = defaultServerLabel).setHorizontalAlignment(2);
        defaultServerLabel.setHorizontalTextPosition(2);
        defaultServerLabel.setText("Label");
        mainPanel.add(defaultServerLabel, new GridConstraints(0, 0, 1, 1, 8, 0, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
    }
    
    private static class ServerListItemWrapper
    {
        ServerConfigForm serverConfigForm;
        
        ServerListItemWrapper(final ServerConfigForm serverConfigForm) {
            this.serverConfigForm = serverConfigForm;
        }
        
        @Override
        public String toString() {
            return this.serverConfigForm.getLabel();
        }
    }
}