/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.viewer;

import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import java.util.Vector;
import com.intellij.openapi.ui.Messages;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.Collections;
import java.util.Arrays;
import java.util.ArrayList;
import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.Container;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.Dimension;
import com.hp.ucmdb.api.discovery.types.DiscoveryResData;
import java.util.List;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import java.util.Map;
import com.intellij.openapi.project.Project;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JDialog;

public class TestFrame extends JDialog
{
    private JPanel contentPane;
    private JTable table;
    private JButton downloadButton;
    private Project project;
    private String[] chosenPackages;
    
    public TestFrame(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup) {
        this.setDefaultCloseOperation(2);
        this.setTitle("Package List");
        this.setPreferredSize(new Dimension(400, 300));
        this.setModal(true);
        (this.contentPane = new JPanel()).setBorder(new EmptyBorder(5, 5, 5, 5));
        this.contentPane.setLayout(new BorderLayout(0, 0));
        this.setContentPane(this.contentPane);
        this.table = new JTable();
        final JScrollPane scrollPane = new JScrollPane(this.table, 22, 30);
        this.contentPane.add(scrollPane, "Center");
        final String[] list = resGroup.keySet().toArray(new String[0]);
        List l = new ArrayList();
        l = Arrays.asList(list);
        Collections.sort((List<Object>)l, (Comparator<? super Object>)new Test());
        final String[] t = l.toArray(new String[l.size()]);
        final Vector data = this.getData(t);
        this.initTable(data);
        this.downloadButton = new JButton("Download");
        this.contentPane.add(this.downloadButton, "Last");
        this.downloadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                final int tableCount = TestFrame.this.table.getRowCount();
                final List<String> packageList = new ArrayList<String>();
                for (int i = 0; i < tableCount; ++i) {
                    if (TestFrame.this.table.getValueAt(i, 0)) {
                        packageList.add((String)TestFrame.this.table.getValueAt(i, 1));
                    }
                }
                if (packageList.isEmpty()) {
                    Messages.showMessageDialog(TestFrame.this.project, "No package has been chosen,please choose a package", "Information", Messages.getInformationIcon());
                }
                else {
                    TestFrame.this.chosenPackages = packageList.toArray(new String[0]);
                    Messages.showMessageDialog(TestFrame.this.project, "The package" + packageList.toString() + " is being downloaded. Please wait for a moment", "Information", Messages.getInformationIcon());
                }
                TestFrame.this.dispose();
            }
        });
        this.pack();
    }
    
    public String[] getChosenPackages() {
        return this.chosenPackages;
    }
    
    public int tableCount() {
        return this.table.getRowCount();
    }
    
    public List chosenPackages(final int tableCount) {
        final List<String> packageList = new ArrayList<String>();
        for (int i = 0; i < tableCount; ++i) {
            if (this.table.getValueAt(i, 0).equals(true)) {
                packageList.add((String)this.table.getValueAt(i, 1));
            }
        }
        return packageList;
    }
    
    public void initTable(final Vector data) {
        final Vector headerNames = new Vector();
        headerNames.add("Select All");
        headerNames.add("Package Name");
        final CheckTableModle tableModel = new CheckTableModle(data, headerNames);
        this.table.setModel((TableModel)tableModel);
        this.table.getTableHeader().setDefaultRenderer((TableCellRenderer)new CheckHeaderCellRenderer(this.table));
    }
    
    public Vector getData(final String[] packageNames) {
        final Vector data = new Vector();
        for (String packageName : packageNames) {
            if (packageName.endsWith(".zip")) {
                packageName = packageName.substring(0, packageName.length() - 4);
            }
            final Vector rowVector1 = new Vector();
            rowVector1.add(false);
            rowVector1.add(packageName);
            data.add(rowVector1);
        }
        return data;
    }
    
    public static void sort(final String[] list) {
        final int len = list.length;
        String temp = null;
        for (int i = 0; i < len - 1; ++i) {
            for (int j = 0; j < len - 1 - i; ++j) {
                if (list[j].compareTo(list[j + 1]) > 0) {
                    temp = list[j];
                    list[j] = list[j + 1];
                    list[j + 1] = temp;
                }
            }
        }
    }
    
    public int compare(final Object o1, final Object o2) {
        final String str1 = o1.toString().toUpperCase();
        final String str2 = o2.toString().toUpperCase();
        return str1.compareTo(str2);
    }
}