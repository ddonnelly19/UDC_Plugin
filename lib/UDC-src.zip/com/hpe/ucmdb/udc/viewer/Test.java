/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.viewer;

import java.util.Comparator;

public class Test implements Comparator
{
    @Override
    public int compare(final Object o1, final Object o2) {
        final String str1 = o1.toString().toUpperCase();
        final String str2 = o2.toString().toUpperCase();
        return str1.compareTo(str2);
    }
}