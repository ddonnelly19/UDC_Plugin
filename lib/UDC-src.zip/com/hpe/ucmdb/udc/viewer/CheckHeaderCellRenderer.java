/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.viewer;

import javax.swing.JComponent;
import javax.swing.UIManager;
import javax.swing.JLabel;
import java.awt.Component;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.JTable;
import javax.swing.JCheckBox;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

public class CheckHeaderCellRenderer implements TableCellRenderer
{
    CheckTableModle tableModel;
    JTableHeader tableHeader;
    JCheckBox selectBox;
    
    public CheckHeaderCellRenderer(final JTable table) {
        this.tableModel = (CheckTableModle)table.getModel();
        this.tableHeader = table.getTableHeader();
        (this.selectBox = new JCheckBox(this.tableModel.getColumnName(1))).setSelected(false);
        this.tableHeader.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                if (e.getClickCount() > 0) {
                    final int selectColumn = CheckHeaderCellRenderer.this.tableHeader.columnAtPoint(e.getPoint());
                    if (selectColumn == 1) {
                        final boolean value = !CheckHeaderCellRenderer.this.selectBox.isSelected();
                        CheckHeaderCellRenderer.this.selectBox.setSelected(value);
                        CheckHeaderCellRenderer.this.tableModel.selectAllOrNull(value);
                        CheckHeaderCellRenderer.this.tableHeader.repaint();
                    }
                }
            }
        });
    }
    
    @Override
    public Component getTableCellRendererComponent(final JTable table, final Object value, final boolean isSelected, final boolean hasFocus, final int row, final int column) {
        final String valueStr = (String)value;
        final JLabel label = new JLabel(valueStr);
        label.setHorizontalAlignment(0);
        this.selectBox.setHorizontalAlignment(0);
        this.selectBox.setBorderPainted(true);
        final JComponent component = (JComponent)((column == 1) ? this.selectBox : label);
        component.setForeground(this.tableHeader.getForeground());
        component.setBackground(this.tableHeader.getBackground());
        component.setFont(this.tableHeader.getFont());
        component.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
        return component;
    }
}