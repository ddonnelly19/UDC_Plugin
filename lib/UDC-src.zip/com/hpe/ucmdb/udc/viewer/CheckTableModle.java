/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.viewer;

import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class CheckTableModle extends DefaultTableModel
{
    public CheckTableModle(final Vector data, final Vector columnNames) {
        super(data, columnNames);
    }
    
    @Override
    public Class getColumnClass(final int c) {
        return this.getValueAt(0, c).getClass();
    }
    
    public void selectAllOrNull(final boolean value) {
        for (int i = 0; i < this.getRowCount(); ++i) {
            this.setValueAt(value, i, 1);
        }
    }
    
    @Override
    public boolean isCellEditable(final int row, final int column) {
        return column != 0;
    }
}