/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.border.Border;
import java.awt.Font;
import javax.swing.BorderFactory;
import java.awt.Color;
import com.intellij.uiDesigner.core.Spacer;
import java.awt.Dimension;
import com.intellij.uiDesigner.core.GridConstraints;
import java.awt.LayoutManager;
import com.intellij.uiDesigner.core.GridLayoutManager;
import java.awt.Insets;
import com.intellij.openapi.application.ApplicationManager;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JComponent;
import java.util.Enumeration;
import java.awt.AWTEvent;
import java.awt.Window;
import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.ui.popup.util.PopupUtil;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.diff.DiffManager;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.diff.DiffRequest;
import com.intellij.openapi.diff.FileContent;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.progress.PerformInBackgroundOption;
import com.intellij.openapi.diff.DiffContent;
import com.intellij.openapi.vfs.VirtualFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.FileInputStream;
import java.util.zip.ZipFile;
import com.intellij.ide.plugins.IdeaPluginDescriptor;
import com.intellij.ide.plugins.PluginManager;
import com.intellij.openapi.extensions.PluginId;
import java.io.IOException;
import com.intellij.openapi.vfs.CharsetToolkit;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.awt.event.MouseListener;
import java.util.Collection;
import java.io.InputStream;
import javax.swing.tree.TreePath;
import com.intellij.lang.Language;
import java.io.File;
import javax.swing.tree.TreeNode;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.Iterator;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.KeyStroke;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.Component;
import java.awt.Container;
import javax.swing.ListModel;
import javax.swing.DefaultListModel;
import java.util.Map;
import com.hpe.ucmdb.udc.model.TemplateEntry;
import java.util.List;
import com.intellij.openapi.project.Project;
import com.hpe.ucmdb.udc.model.ReturnValue;
import javax.swing.JTextArea;
import javax.swing.JTree;
import com.intellij.ui.components.JBTextField;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JDialog;

public class UiTemplate extends JDialog
{
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JList templateList;
    private JTextField textField1;
    private JTextField textField2;
    private JBTextField textField3;
    private JTextField textField5;
    private JTree tree1;
    private JPanel pane3;
    private JTextArea textArea1;
    private String selectedTemplate;
    private ReturnValue returnValue;
    private String description;
    private byte[] byte2;
    
    public UiTemplate(final Project project, final List<TemplateEntry> templates, final Map<String, String> descriptions) {
        this.$$$setupUI$$$();
        final DefaultListModel<String> templateListModel = new DefaultListModel<String>();
        for (final TemplateEntry template : templates) {
            if (!templateListModel.contains(template.getTemplateName())) {
                templateListModel.addElement(template.getTemplateName());
            }
        }
        this.templateList.setModel(templateListModel);
        this.setContentPane(this.contentPane);
        this.setModal(true);
        this.setTitle("Template List");
        this.setBounds(0, 0, 800, 660);
        this.setLocationRelativeTo(null);
        this.getRootPane().setDefaultButton(this.buttonOK);
        this.templateList.setSelectionMode(0);
        this.templateList.setSelectedIndex(0);
        this.selectedTemplate = this.templateList.getSelectedValue();
        this.textField1.setText(this.selectedTemplate);
        final DefaultTreeModel model = (DefaultTreeModel)this.tree1.getModel();
        final DefaultMutableTreeNode root = (DefaultMutableTreeNode)model.getRoot();
        root.setUserObject(this.selectedTemplate);
        root.remove(root.getNextNode());
        root.remove(root.getNextNode());
        root.remove(root.getNextNode());
        final List<TemplateEntry> jTreeNodes = new ArrayList<TemplateEntry>();
        for (final TemplateEntry temp : templates) {
            if (temp.getTemplateName().equals(this.selectedTemplate)) {
                jTreeNodes.add(temp);
            }
        }
        for (final TemplateEntry t : jTreeNodes) {
            final List<String> ts = (List<String>)t.getFolder();
            DefaultMutableTreeNode n = null;
            if (ts != null) {
                for (int i = 0; i < ts.size(); ++i) {
                    if (i == 0) {
                        if (this.findChild(ts.get(i), root) == null) {
                            n = new DefaultMutableTreeNode(ts.get(i));
                            model.insertNodeInto(n, root, root.getChildCount());
                        }
                        else {
                            n = this.findChild(ts.get(i), root);
                        }
                    }
                    else if (this.findChild(ts.get(i), root) == null) {
                        final DefaultMutableTreeNode n2 = new DefaultMutableTreeNode(ts.get(i));
                        model.insertNodeInto(n2, n, n.getChildCount());
                        n = n2;
                    }
                    else {
                        n = this.findChild(ts.get(i), root);
                    }
                }
                final DefaultMutableTreeNode file = new DefaultMutableTreeNode(t.getFile());
                model.insertNodeInto(file, n, n.getChildCount());
            }
            else {
                final DefaultMutableTreeNode file = new DefaultMutableTreeNode(t.getFile());
                model.insertNodeInto(file, root, 0);
            }
        }
        this.description = "";
        for (final Map.Entry<String, String> entry : descriptions.entrySet()) {
            if (entry.getKey().equals(this.selectedTemplate + ".zip")) {
                this.description = entry.getValue();
            }
        }
        this.textArea1.setText(this.description);
        this.tree1.updateUI();
        this.buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                if (UiTemplate.this.getDataRequirement()) {
                    UiTemplate.this.returnValue = new ReturnValue();
                    UiTemplate.this.returnValue.setTemplateName(UiTemplate.this.selectedTemplate);
                    UiTemplate.this.returnValue.setSetTemplateName(UiTemplate.this.textField1.getText().trim());
                    UiTemplate.this.returnValue.setAdapterName(UiTemplate.this.textField2.getText().trim());
                    UiTemplate.this.returnValue.setJobName(UiTemplate.this.textField3.getText().trim());
                    UiTemplate.this.returnValue.setScriptsName(UiTemplate.this.textField5.getText().trim());
                    UiTemplate.this.returnValue.setDescription(UiTemplate.this.description);
                    UiTemplate.this.dispose();
                }
            }
        });
        this.buttonCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                try {
                    UiTemplate.this.quit();
                }
                catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        this.setDefaultCloseOperation(0);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                UiTemplate.this.onCancel();
            }
        });
        this.contentPane.registerKeyboardAction(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                UiTemplate.this.onCancel();
            }
        }, KeyStroke.getKeyStroke(27, 0), 1);
        this.templateList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(final ListSelectionEvent e) {
                final String selected = UiTemplate.this.templateList.getSelectedValue();
                UiTemplate.this.selectedTemplate = selected;
                UiTemplate.this.textField1.setText(selected);
                final DefaultTreeModel model = (DefaultTreeModel)UiTemplate.this.tree1.getModel();
                final DefaultMutableTreeNode root = (DefaultMutableTreeNode)model.getRoot();
                root.removeAllChildren();
                final List<TemplateEntry> jTreeNodes = new ArrayList<TemplateEntry>();
                for (final TemplateEntry temp : templates) {
                    if (temp.getTemplateName().equals(selected)) {
                        jTreeNodes.add(temp);
                    }
                }
                for (final TemplateEntry t : jTreeNodes) {
                    final List<String> ts = (List<String>)t.getFolder();
                    DefaultMutableTreeNode n = null;
                    if (ts != null) {
                        for (int i = 0; i < ts.size(); ++i) {
                            if (i == 0) {
                                if (UiTemplate.this.findChild(ts.get(i), root) == null) {
                                    n = new DefaultMutableTreeNode(ts.get(i));
                                    model.insertNodeInto(n, root, root.getChildCount());
                                }
                                else {
                                    n = UiTemplate.this.findChild(ts.get(i), root);
                                }
                            }
                            else {
                                final List<String> parentFolders = new ArrayList<String>();
                                for (int j = i - 1; j >= 0; --j) {
                                    parentFolders.add(ts.get(j));
                                }
                                if (UiTemplate.this.findChild2(ts.get(i), root, parentFolders, t.getTemplateName()) == null || !UiTemplate.this.findChildByParent(parentFolders, UiTemplate.this.findChild2(ts.get(i), root, parentFolders, t.getTemplateName()))) {
                                    final DefaultMutableTreeNode n2 = new DefaultMutableTreeNode(ts.get(i));
                                    model.insertNodeInto(n2, n, n.getChildCount());
                                    n = n2;
                                }
                                else {
                                    n = UiTemplate.this.findChild2(ts.get(i), root, parentFolders, t.getTemplateName());
                                }
                            }
                        }
                        final DefaultMutableTreeNode file = new DefaultMutableTreeNode(t.getFile());
                        model.insertNodeInto(file, n, n.getChildCount());
                    }
                    else {
                        final DefaultMutableTreeNode file = new DefaultMutableTreeNode(t.getFile());
                        model.insertNodeInto(file, root, 0);
                    }
                }
                UiTemplate.this.description = "";
                for (final Map.Entry<String, String> entry : descriptions.entrySet()) {
                    if (entry.getKey().equals(selected + ".zip")) {
                        UiTemplate.this.description = entry.getValue();
                    }
                }
                UiTemplate.this.textArea1.setText(UiTemplate.this.description);
                UiTemplate.this.tree1.updateUI();
            }
        });
        this.textField1.getDocument().addDocumentListener(new DocumentListener() {
            DefaultTreeModel model = (DefaultTreeModel)UiTemplate.this.tree1.getModel();
            DefaultMutableTreeNode root = (DefaultMutableTreeNode)this.model.getRoot();
            
            @Override
            public void insertUpdate(final DocumentEvent e) {
                this.root.setUserObject(UiTemplate.this.textField1.getText());
                UiTemplate.this.tree1.updateUI();
            }
            
            @Override
            public void removeUpdate(final DocumentEvent e) {
                this.root.setUserObject(UiTemplate.this.textField1.getText());
                UiTemplate.this.tree1.updateUI();
            }
            
            @Override
            public void changedUpdate(final DocumentEvent e) {
                this.root.setUserObject(UiTemplate.this.textField1.getText());
                UiTemplate.this.tree1.updateUI();
            }
        });
        this.textArea1.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(final DocumentEvent e) {
                UiTemplate.this.description = UiTemplate.this.textArea1.getText();
            }
            
            @Override
            public void removeUpdate(final DocumentEvent e) {
                UiTemplate.this.description = UiTemplate.this.textArea1.getText();
            }
            
            @Override
            public void changedUpdate(final DocumentEvent e) {
                UiTemplate.this.description = UiTemplate.this.textArea1.getText();
            }
        });
        this.tree1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(final MouseEvent e) {
                if (e.getClickCount() == 2) {
                    final TreePath path = UiTemplate.this.tree1.getPathForLocation(e.getX(), e.getY());
                    String text = "";
                    if (path != null && path.getLastPathComponent() != null) {
                        final TreeNode node = (TreeNode)path.getLastPathComponent();
                        if (node.isLeaf()) {
                            final List<String> nodes = new ArrayList<String>();
                            nodes.add(node.toString());
                            nodes.add(UiTemplate.this.selectedTemplate);
                            final String zipPath = UiTemplate.this.getZIPsPath(nodes);
                            final File model = new File(zipPath);
                            try {
                                UiTemplate.this.byte2 = UiTemplate.input2byte(UiTemplate.getFile(model, nodes));
                                final InputStream fr = UiTemplate.getFile(model, nodes);
                                text = UiTemplate.this.inputStream2String(fr);
                                text = text.replace("\r\n", "\n");
                            }
                            catch (Exception e2) {
                                e2.printStackTrace();
                            }
                            final Collection<Language> registeredLanguages = (Collection<Language>)Language.getRegisteredLanguages();
                            System.out.println(registeredLanguages);
                            Language xml = Language.findLanguageByID("TEXT");
                            if (node.toString().endsWith(".py")) {
                                xml = Language.findLanguageByID("Python");
                            }
                            else if (node.toString().endsWith(".xml")) {
                                xml = Language.findLanguageByID("XML");
                            }
                            text = text.replace("\r\n", "\n");
                            final FileUI fu = new FileUI(xml, project, text);
                            fu.setTitle(node.toString());
                            fu.setVisible(true);
                        }
                    }
                }
            }
        });
    }
    
    public String inputStream2String(InputStream in) throws IOException {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        in = new BufferedInputStream(in);
        final byte[] b = new byte[4096];
        int n;
        while ((n = in.read(b)) != -1) {
            out.write(b, 0, n);
        }
        final byte[] bytes = out.toByteArray();
        return CharsetToolkit.bytesToString(bytes, CharsetToolkit.UTF8_CHARSET);
    }
    
    private String getZIPsPath(final List<String> nodes) {
        String zipsPath = "";
        final PluginId pyhelper1 = PluginId.getId("UDC");
        final IdeaPluginDescriptor plugin = PluginManager.getPlugin(pyhelper1);
        assert plugin != null;
        final File pyhelper2 = plugin.getPath();
        System.out.println(pyhelper2.getAbsolutePath());
        final File root = new File(pyhelper2, "lib");
        System.out.println(root.exists());
        final File[] fs = root.listFiles();
        for (int i = 0; i < fs.length; ++i) {
            if (fs[i].getAbsolutePath().endsWith(nodes.get(nodes.size() - 1) + ".zip")) {
                zipsPath = fs[i].getAbsolutePath();
            }
        }
        return zipsPath;
    }
    
    public static InputStream getFile(final File file, final List<String> nodes) throws Exception {
        InputStream is = null;
        final ZipFile zipFile = new ZipFile(file.getCanonicalPath());
        final InputStream in = new BufferedInputStream(new FileInputStream(file));
        final ZipInputStream zin = new ZipInputStream(in);
        ZipEntry ze;
        while ((ze = zin.getNextEntry()) != null) {
            if (ze.getName().endsWith(nodes.get(0))) {
                is = zipFile.getInputStream(ze);
            }
            zin.closeEntry();
        }
        return is;
    }
    
    public static final byte[] input2byte(final InputStream inStream) throws IOException {
        final ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        final byte[] buff = new byte[100];
        int rc = 0;
        while ((rc = inStream.read(buff, 0, 100)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        final byte[] in2b = swapStream.toByteArray();
        inStream.close();
        return in2b;
    }
    
    private void diff(final Project project, final VirtualFile file, final DiffContent local) {
        final Task.Backgroundable task = new Task.Backgroundable(project, "Diffing @" + ServerConfigManager.getInstance().getDefaultServerConfig(project).getServer(), false, new PerformInBackgroundOption() {
            public boolean shouldStartInBackground() {
                return true;
            }
            
            public void processSentToBackground() {
            }
        }) {
            byte[] content = UiTemplate.this.byte2;
            
            public void onSuccess() {
                if (this.content != null) {
                    final DiffContent server = (DiffContent)new FileContent(project, file);
                    local.getDocument().setReadOnly(false);
                    server.getDocument().setReadOnly(true);
                    final DiffRequest dr = new DiffRequest(project) {
                        @NotNull
                        public DiffContent[] getContents() {
                            final DiffContent[] array = { local, server };
                            if (array == null) {
                                throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/UiTemplate$10$1", "getContents"));
                            }
                            return array;
                        }
                        
                        public String[] getContentTitles() {
                            return new String[] { file.getName() + "1", file.getName() + "2" };
                        }
                        
                        public String getWindowTitle() {
                            return file.getName();
                        }
                    };
                    dr.setOnOkRunnable((Runnable)new Runnable() {
                        @Override
                        public void run() {
                        }
                    });
                    DiffManager.getInstance().getDiffTool().show(dr);
                }
                else {
                    PopupUtil.showBalloonForActiveComponent("Can't get content ", MessageType.ERROR);
                }
            }
            
            public void run(@NotNull final ProgressIndicator progressIndicator) {
                if (progressIndicator == null) {
                    throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "progressIndicator", "com/hpe/ucmdb/udc/UiTemplate$10", "run"));
                }
                progressIndicator.setIndeterminate(true);
            }
        };
        ProgressManager.getInstance().run((Task)task);
    }
    
    private void onOK() {
        this.dispose();
    }
    
    private void onCancel() {
        this.dispose();
    }
    
    public void quit() throws Exception {
        this.dispatchEvent(new WindowEvent(this, 201));
    }
    
    private DefaultMutableTreeNode findChild(final String chlidName, final DefaultMutableTreeNode root) {
        DefaultMutableTreeNode node = null;
        final Enumeration e = root.breadthFirstEnumeration();
        while (e.hasMoreElements()) {
            node = e.nextElement();
            if (chlidName.equals(node.getUserObject().toString())) {
                return node;
            }
        }
        return null;
    }
    
    private DefaultMutableTreeNode findChild2(final String chlidName, final DefaultMutableTreeNode root, final List<String> folders, final String templateName) {
        DefaultMutableTreeNode node = null;
        final DefaultMutableTreeNode n = null;
        final Enumeration e = root.breadthFirstEnumeration();
        while (e.hasMoreElements()) {
            node = e.nextElement();
            if (chlidName.equals(node.getUserObject().toString())) {
                boolean a = true;
                final List<String> xixi = new ArrayList<String>();
                for (final TreeNode tr : node.getPath()) {
                    if (!tr.toString().equals(root.getUserObject()) && !tr.toString().equals(chlidName)) {
                        xixi.add(tr.toString());
                    }
                }
                if (xixi.size() != folders.size()) {
                    a = false;
                }
                for (int i = 0; i < xixi.size(); ++i) {
                    if (!xixi.get(xixi.size() - 1 - i).equals(folders.get(i))) {
                        a = false;
                    }
                }
                if (a) {
                    return node;
                }
                continue;
            }
        }
        return null;
    }
    
    private boolean findChildByParent(final List<String> folders, final DefaultMutableTreeNode node) {
        if (node == null) {
            return false;
        }
        DefaultMutableTreeNode n = null;
        boolean a = true;
        for (int i = 0; i < folders.size(); ++i) {
            if (i == 0) {
                n = (DefaultMutableTreeNode)node.getParent();
                if (!n.getUserObject().equals(folders.get(i))) {
                    a = false;
                }
            }
            else {
                n = (DefaultMutableTreeNode)n.getParent();
                if (!n.getUserObject().equals(folders.get(i))) {
                    a = false;
                }
            }
        }
        return a;
    }
    
    public ReturnValue getReturnValue() {
        return this.returnValue;
    }
    
    private boolean getDataRequirement() {
        final String templateName = this.textField1.getText().trim();
        final String adapterName = this.textField2.getText().trim();
        final String jobName = this.textField3.getText().trim();
        final String scriptsName = this.textField5.getText().trim();
        if (templateName.trim().length() == 0) {
            this.setFocus(this.textField1);
            PopupUtil.showBalloonForActiveComponent("Package Name must be supplied.", MessageType.ERROR);
            return false;
        }
        if (adapterName.trim().length() == 0) {
            this.setFocus(this.textField2);
            PopupUtil.showBalloonForActiveComponent("Adapter Name must be supplied.", MessageType.ERROR);
            return false;
        }
        if (jobName.trim().length() == 0) {
            this.setFocus((JComponent)this.textField3);
            PopupUtil.showBalloonForActiveComponent("Job Name must be supplied.", MessageType.ERROR);
            return false;
        }
        if (scriptsName.trim().length() == 0) {
            this.setFocus(this.textField5);
            PopupUtil.showBalloonForActiveComponent("Scripts Name must be supplied.", MessageType.ERROR);
            return false;
        }
        final String regEx = "^+[A-Za-z0-9\\s?_-]{1,50}$";
        final Pattern pattern = Pattern.compile(regEx);
        final Matcher matcher = pattern.matcher(templateName);
        final boolean rsTemplateName = matcher.matches();
        final Matcher matcher2 = pattern.matcher(adapterName);
        final boolean rsAdapterName = matcher2.matches();
        final Matcher matcher3 = pattern.matcher(jobName);
        final boolean rsJobName = matcher3.matches();
        final Matcher matcher4 = pattern.matcher(scriptsName);
        final boolean rsScriptsName = matcher4.matches();
        if (!rsTemplateName) {
            this.setFocus(this.textField1);
            PopupUtil.showBalloonForActiveComponent("Package name should only contain English alphabets, numbers, blanks, '-' and '_'. And its length shouldn't be greater than 50.", MessageType.ERROR);
            return false;
        }
        if (!rsAdapterName) {
            this.setFocus(this.textField2);
            PopupUtil.showBalloonForActiveComponent("Adapter name should only contain English alphabets, numbers, '-' and '_'. And its length shouldn't be greater than 50.", MessageType.ERROR);
            return false;
        }
        if (!rsJobName) {
            this.setFocus((JComponent)this.textField3);
            PopupUtil.showBalloonForActiveComponent("Job name should only contain English alphabets, numbers, '-' and '_'. And its length shouldn't be greater than 50.", MessageType.ERROR);
            return false;
        }
        if (!rsScriptsName) {
            this.setFocus(this.textField5);
            PopupUtil.showBalloonForActiveComponent("Script name should only contain English alphabets, numbers, '-' and '_'. And its length shouldn't be greater than 50.", MessageType.ERROR);
            return false;
        }
        return true;
    }
    
    private void setFocus(final JComponent component) {
        ApplicationManager.getApplication().invokeLater((Runnable)new Runnable() {
            @Override
            public void run() {
                component.requestFocus();
            }
        });
    }
    
    public static void main(final String[] args) {
        final UiTemplate dialog = new UiTemplate(null, null, (Map<String, String>)null);
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
    
    private  void $$$setupUI$$$() {
        final JPanel contentPane = new JPanel();
        (this.contentPane = contentPane).setLayout((LayoutManager)new GridLayoutManager(2, 2, new Insets(10, 10, 10, 10), -1, -1, false, false));
        final JPanel panel = new JPanel();
        panel.setLayout((LayoutManager)new GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel, new GridConstraints(1, 1, 1, 1, 0, 3, 7, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        panel.add((Component)new Spacer(), new GridConstraints(0, 0, 1, 1, 0, 1, 6, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel2 = new JPanel();
        panel2.setLayout((LayoutManager)new GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1, true, false));
        panel.add(panel2, new GridConstraints(0, 1, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton buttonOK = new JButton();
        (this.buttonOK = buttonOK).setText("OK");
        panel2.add(buttonOK, new GridConstraints(0, 0, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton buttonCancel = new JButton();
        (this.buttonCancel = buttonCancel).setText("Cancel");
        panel2.add(buttonCancel, new GridConstraints(0, 1, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel3 = new JPanel();
        panel3.setLayout((LayoutManager)new GridLayoutManager(2, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel3, new GridConstraints(0, 1, 1, 1, 0, 3, 3, 7, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel4 = new JPanel();
        panel4.setLayout((LayoutManager)new GridLayoutManager(5, 2, new Insets(2, 2, 2, 2), -1, -1, false, false));
        panel3.add(panel4, new GridConstraints(0, 0, 1, 1, 0, 3, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        panel4.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), null, 0, 0, null, null));
        final JLabel label = new JLabel();
        label.setText("Package Name :");
        panel4.add(label, new GridConstraints(0, 0, 1, 1, 8, 0, 0, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        panel4.add(this.textField1 = new JTextField(), new GridConstraints(0, 1, 1, 1, 8, 1, 6, 0, (Dimension)null, new Dimension(100, -1), (Dimension)null));
        final JLabel label2 = new JLabel();
        label2.setText("$PATTERN_NAME :");
        panel4.add(label2, new GridConstraints(1, 0, 1, 1, 8, 0, 0, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JLabel label3 = new JLabel();
        label3.setText("$JOB_NAME :");
        panel4.add(label3, new GridConstraints(2, 0, 1, 1, 8, 0, 0, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JLabel label4 = new JLabel();
        label4.setText("$SCRIPTS_NAME :");
        panel4.add(label4, new GridConstraints(3, 0, 1, 1, 8, 0, 0, 4, (Dimension)null, (Dimension)null, (Dimension)null));
        panel4.add(this.textField2 = new JTextField(), new GridConstraints(1, 1, 1, 1, 8, 1, 6, 0, (Dimension)null, new Dimension(100, -1), (Dimension)null));
        panel4.add((Component)(this.textField3 = new JBTextField()), new GridConstraints(2, 1, 1, 1, 8, 1, 6, 0, (Dimension)null, new Dimension(100, -1), (Dimension)null));
        final JTextField textField5 = new JTextField();
        (this.textField5 = textField5).setText("");
        panel4.add(textField5, new GridConstraints(3, 1, 1, 1, 8, 1, 6, 0, (Dimension)null, new Dimension(100, -1), (Dimension)null));
        panel4.add(this.textArea1 = new JTextArea(), new GridConstraints(4, 1, 1, 1, 0, 3, 6, 6, (Dimension)null, new Dimension(100, 50), (Dimension)null));
        final JLabel label5 = new JLabel();
        label5.setText("Description :");
        panel4.add(label5, new GridConstraints(4, 0, 1, 1, 8, 0, 0, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel pane3 = new JPanel();
        (this.pane3 = pane3).setLayout((LayoutManager)new GridLayoutManager(1, 1, new Insets(2, 0, 2, 0), -1, -1, false, false));
        panel3.add(pane3, new GridConstraints(1, 0, 1, 1, 0, 3, 3, 7, (Dimension)null, (Dimension)null, (Dimension)null));
        final JScrollPane scrollPane = new JScrollPane();
        pane3.add(scrollPane, new GridConstraints(0, 0, 1, 1, 0, 3, 7, 7, (Dimension)null, (Dimension)null, (Dimension)null));
        final JTree tree = new JTree();
        (this.tree1 = tree).putClientProperty("JTree.lineStyle", "");
        scrollPane.setViewportView(tree);
        final JPanel panel5 = new JPanel();
        panel5.setLayout((LayoutManager)new GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel5, new GridConstraints(0, 0, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JScrollPane scrollPane2 = new JScrollPane();
        panel5.add(scrollPane2, new GridConstraints(0, 0, 1, 1, 0, 3, 7, 7, (Dimension)null, new Dimension(256, 619), (Dimension)null));
        final JList list = new JList();
        (this.templateList = list).setModel(new DefaultListModel());
        list.putClientProperty("List.isFileList", Boolean.FALSE);
        scrollPane2.setViewportView(list);
        panel5.add((Component)new Spacer(), new GridConstraints(0, 1, 1, 1, 0, 1, 6, 1, (Dimension)null, (Dimension)null, (Dimension)null));
    }
}