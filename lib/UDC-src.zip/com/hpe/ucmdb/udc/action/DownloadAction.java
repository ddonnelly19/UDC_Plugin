/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.action;

import com.intellij.openapi.roots.ProjectFileIndex;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtil;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.hpe.ucmdb.udc.PackageList;
import java.io.IOException;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import com.hpe.ucmdb.udc.ResTypeUtil;
import com.intellij.openapi.progress.ProgressManager;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.ui.popup.util.PopupUtil;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.progress.PerformInBackgroundOption;
import java.util.Iterator;
import java.util.Collection;
import com.intellij.openapi.ui.Messages;
import java.util.Comparator;
import java.util.Collections;
import com.hpe.ucmdb.udc.viewer.Test;
import java.util.ArrayList;
import com.hp.ucmdb.api.discovery.types.DiscoveryResData;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.hpe.ucmdb.udc.ServerConfig;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import com.hpe.ucmdb.udc.ServerConfigManager;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.project.Project;
import com.hpe.ucmdb.udc.UDCHelper;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.actionSystem.AnAction;

public class DownloadAction extends AnAction
{
    private static VirtualFile root;
    private static UDCHelper udcHelper;
    private Project project;
    
    public void actionPerformed(final AnActionEvent e) {
        this.project = e.getProject();
        this.getRootFolder(e);
        final ServerConfig serverConfig = ServerConfigManager.getInstance().getDefaultServerConfig(e.getProject());
        if (serverConfig == null) {
            return;
        }
        DownloadAction.udcHelper = new UDCHelper(this.project, serverConfig);
        final DiscoveryResType[] resTypes = { DiscoveryResType.ADAPTER, DiscoveryResType.JOB, DiscoveryResType.SCRIPT, DiscoveryResType.SERVER_DATA, DiscoveryResType.USER_EXT };
        try {
            this.connectSeverInBackground(DownloadAction.udcHelper, resTypes);
        }
        catch (Exception e2) {
            e2.printStackTrace();
        }
    }
    
    private void download(final UDCHelper udcHelper, final DiscoveryResType[] resTypes) throws Exception {
        final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup = new HashMap<String, Map<DiscoveryResType, List<DiscoveryResData>>>();
        for (final DiscoveryResType resType : resTypes) {
            final Collection<DiscoveryResData> discoveryResList = (Collection<DiscoveryResData>)udcHelper.listResources(resType);
            for (final DiscoveryResData res : discoveryResList) {
                String packageName = res.getPackageName();
                if (packageName == null) {
                    continue;
                }
                if (packageName.endsWith(".zip")) {
                    packageName = packageName.substring(0, packageName.length() - 4);
                }
                Map<DiscoveryResType, List<DiscoveryResData>> resourcesPerPackageMap = resGroup.get(packageName);
                if (resourcesPerPackageMap == null) {
                    resourcesPerPackageMap = new HashMap<DiscoveryResType, List<DiscoveryResData>>();
                    resGroup.put(packageName, resourcesPerPackageMap);
                }
                List<DiscoveryResData> resourcePerPackage = resourcesPerPackageMap.get(resType);
                if (resourcePerPackage == null) {
                    resourcePerPackage = new ArrayList<DiscoveryResData>();
                    resourcesPerPackageMap.put(resType, resourcePerPackage);
                }
                resourcePerPackage.add(res);
            }
        }
        final String[] chosenPackageNames = this.showChooseResourceUI(resGroup);
        final List<String> loadedPackages = new ArrayList<String>();
        if (chosenPackageNames != null) {
            for (final String packageName2 : chosenPackageNames) {
                if (DownloadAction.root.findChild(packageName2) != null) {
                    loadedPackages.add(packageName2);
                }
            }
        }
        if (chosenPackageNames != null) {
            if (loadedPackages.size() != 0) {
                Collections.sort(loadedPackages, (Comparator<? super String>)new Test());
                if (Messages.showOkCancelDialog(this.project, "This destination already contains  package(s) named " + loadedPackages.toString() + ". If any files have the same names, you will be asked if you want to replace those files. Do you still want to merge the folder(s)? ", "Confirmation", "Yes", "No", Messages.getInformationIcon()) == 0) {
                    this.pullInBackground(resGroup, chosenPackageNames);
                }
            }
            else {
                this.pullInBackground(resGroup, chosenPackageNames);
            }
        }
    }
    
    private void pullInBackground(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup, final String[] chosenPackageNames) {
        final Task.Backgroundable task = new Task.Backgroundable(this.project, "Running", false, new PerformInBackgroundOption() {
            public boolean shouldStartInBackground() {
                return false;
            }
            
            public void processSentToBackground() {
            }
        }) {
            int total1 = 0;
            List<TempData> tempDataList = new ArrayList<TempData>();
            Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> tempDataMap = new HashMap<String, Map<DiscoveryResType, List<DiscoveryResData>>>();
            
            public void onSuccess() {
                ApplicationManager.getApplication().invokeLater((Runnable)new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("Begin write to disk...");
                        VirtualFileManager.getInstance().syncRefresh();
                        PopupUtil.showBalloonForActiveComponent("Done. Total " + chosenPackageNames.length + " packages have been downloaded.", MessageType.INFO);
                    }
                });
            }
            
            public void run(@NotNull final ProgressIndicator progressIndicator) {
                if (progressIndicator == null) {
                    throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "progressIndicator", "com/hpe/ucmdb/udc/action/DownloadAction$2", "run"));
                }
                try {
                    progressIndicator.setText("Fetching file list...");
                    progressIndicator.setFraction(0.2);
                    for (int i = 0; i < chosenPackageNames.length; ++i) {
                        final String packageName = chosenPackageNames[i];
                        progressIndicator.setText("Downloading " + packageName);
                        final List<TempData> tempDataList2 = DownloadAction.downloadSinglePackage1(this.tempDataMap, this.tempDataList, packageName, resGroup.get(packageName));
                        writePackage(tempDataList2);
                        ApplicationManager.getApplication().invokeLater((Runnable)new Runnable() {
                            @Override
                            public void run() {
                                DownloadAction.root.getFileSystem().refresh(true);
                            }
                        });
                        progressIndicator.setFraction((i + 1.0) / chosenPackageNames.length);
                    }
                }
                catch (Exception e) {
                    PopupUtil.showBalloonForActiveFrame((e.getMessage() != null) ? e.getMessage() : "Error", MessageType.ERROR);
                    throw new RuntimeException(e);
                }
            }
        };
        ProgressManager.getInstance().run((Task)task);
    }
    
    public static void downloadSinglePackage2(final List<TempData> tempDataList) throws Exception {
        for (final TempData tempData : tempDataList) {
            final List<String> subFols = tempData.subFol;
            final VirtualFile childDirectory = findOrCreateChildDirectory(DownloadAction.root, (String)tempData.o4);
            final VirtualFile resTypeFolder = findOrCreateChildDirectory(childDirectory, ResTypeUtil.getResName((DiscoveryResType)tempData.o1));
            VirtualFile sub = null;
            final List<VirtualFile> temp = new ArrayList<VirtualFile>();
            if (subFols.size() > 0) {
                for (int i = 0; i < subFols.size(); ++i) {
                    if (i == 0) {
                        sub = findOrCreateChildDirectory(resTypeFolder, subFols.get(0));
                        temp.add(sub);
                    }
                    else {
                        sub = findOrCreateChildDirectory(temp.get(temp.size() - 1), subFols.get(i));
                        temp.add(sub);
                    }
                }
            }
            else {
                sub = resTypeFolder;
            }
            final byte[] content = (byte[])tempData.o3;
            String dataName = (String)tempData.o2;
            if (resTypeFolder.getName().equals("discoveryPatterns")) {
                dataName += ".xml";
            }
            writeSingleResource(sub, dataName, content);
        }
    }
    
    private static void writePackage(final List<TempData> tempDataList) throws Exception {
        for (final TempData tempData : tempDataList) {
            final List<String> subFols = tempData.subFol;
            final File childDirectory = new File(DownloadAction.root.getPath(), (String)tempData.o4);
            if (!childDirectory.exists()) {
                childDirectory.mkdirs();
            }
            final File resTypeFolder = new File(childDirectory.getPath(), ResTypeUtil.getResName((DiscoveryResType)tempData.o1));
            if (!resTypeFolder.exists()) {
                resTypeFolder.mkdirs();
            }
            File sub = null;
            final List<File> temp = new ArrayList<File>();
            if (subFols.size() > 0) {
                for (int i = 0; i < subFols.size(); ++i) {
                    if (i == 0) {
                        sub = new File(resTypeFolder, subFols.get(0));
                        if (!sub.exists()) {
                            sub.mkdirs();
                        }
                        temp.add(sub);
                    }
                    else {
                        sub = new File(temp.get(temp.size() - 1), subFols.get(i));
                        if (!sub.exists()) {
                            sub.mkdirs();
                        }
                        temp.add(sub);
                    }
                }
            }
            else {
                sub = resTypeFolder;
            }
            final byte[] content = (byte[])tempData.o3;
            String dataName = (String)tempData.o2;
            if (resTypeFolder.getName().equals("discoveryPatterns")) {
                dataName += ".xml";
            }
            final File aim = new File(sub.getPath() + "\\" + dataName);
            BufferedOutputStream bos = null;
            FileOutputStream fos = null;
            fos = new FileOutputStream(aim);
            bos = new BufferedOutputStream(fos);
            bos.write(content);
            bos.close();
            fos.close();
        }
    }
    
    public static void downloadSinglePackage(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> tempDataMap, final List<TempData> tempDataList, final String packageName, final Map<DiscoveryResType, List<DiscoveryResData>> discoveryResourceTypeListMap) throws Exception {
        for (final DiscoveryResType resType : discoveryResourceTypeListMap.keySet()) {
            final List<DiscoveryResData> discoveryResDataList = discoveryResourceTypeListMap.get(resType);
            for (final DiscoveryResData resData : discoveryResDataList) {
                final byte[] content = DownloadAction.udcHelper.getContent(resType, resData.getResourceName());
                final int nameLength = resData.getResourceName().split("/").length;
                final List<String> subFol = new ArrayList<String>();
                if (nameLength >= 2) {
                    for (int i = 0; i < nameLength - 1; ++i) {
                        subFol.add(resData.getResourceName().split("/")[i]);
                    }
                }
                final String dataName = resData.getResourceName().split("/")[nameLength - 1];
                final TempData tempData = new TempData(resType, dataName, content, packageName, subFol);
                tempDataList.add(tempData);
            }
        }
    }
    
    public static List<TempData> downloadSinglePackage1(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> tempDataMap, final List<TempData> tempDataList, final String packageName, final Map<DiscoveryResType, List<DiscoveryResData>> discoveryResourceTypeListMap) throws Exception {
        final List<TempData> tempList = new ArrayList<TempData>();
        for (final DiscoveryResType resType : discoveryResourceTypeListMap.keySet()) {
            final List<DiscoveryResData> discoveryResDataList = discoveryResourceTypeListMap.get(resType);
            for (final DiscoveryResData resData : discoveryResDataList) {
                final byte[] content = DownloadAction.udcHelper.getContent(resType, resData.getResourceName());
                final int nameLength = resData.getResourceName().split("/").length;
                final List<String> subFol = new ArrayList<String>();
                if (nameLength >= 2) {
                    for (int i = 0; i < nameLength - 1; ++i) {
                        subFol.add(resData.getResourceName().split("/")[i]);
                    }
                }
                final String dataName = resData.getResourceName().split("/")[nameLength - 1];
                final TempData tempData = new TempData(resType, dataName, content, packageName, subFol);
                tempList.add(tempData);
            }
        }
        return tempList;
    }
    
    private static void writeSingleResource(final VirtualFile resTypeFolder, final String resourceName, final byte[] content) throws IOException {
        ApplicationManager.getApplication().runWriteAction((Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    final VirtualFile child = resTypeFolder.findOrCreateChildData((Object)null, resourceName);
                    child.setBinaryContent(content);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("Write to file:" + resourceName);
            }
        });
    }
    
    private static VirtualFile findOrCreateChildDirectory(final VirtualFile parent, final String childName) throws IOException {
        ApplicationManager.getApplication().runWriteAction((Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    final VirtualFile childDirectory = parent.findChild(childName);
                    if (childDirectory == null || !childDirectory.exists()) {
                        parent.createChildDirectory((Object)null, childName);
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("create folder to file:" + childName);
            }
        });
        return parent.findChild(childName);
    }
    
    private String[] showChooseResourceUI(final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup) {
        final PackageList packageList = new PackageList((Map)resGroup);
        packageList.setVisible(true);
        return packageList.getChosenPackages();
    }
    
    private void getRootFolder(final AnActionEvent e) {
        if (DownloadAction.root == null) {
            final VirtualFile[] vFiles = (VirtualFile[])e.getData(PlatformDataKeys.VIRTUAL_FILE_ARRAY);
            if (vFiles == null || vFiles.length != 1) {
                Messages.showWarningDialog("Only need one folder.", "Error");
            }
            else {
                DownloadAction.root = vFiles[0];
            }
        }
    }
    
    private void connectSeverInBackground(final UDCHelper udcHelper, final DiscoveryResType[] resTypes) {
        final Task.Backgroundable task = new Task.Backgroundable(this.project, "Running", false, new PerformInBackgroundOption() {
            public boolean shouldStartInBackground() {
                return false;
            }
            
            public void processSentToBackground() {
            }
        }) {
            int total1 = 0;
            
            public void onSuccess() {
                ApplicationManager.getApplication().runWriteAction((Runnable)new Runnable() {
                    @Override
                    public void run() {
                        try {
                            DownloadAction.this.download(udcHelper, resTypes);
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
            
            public void run(@NotNull final ProgressIndicator progressIndicator) {
                if (progressIndicator == null) {
                    throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "progressIndicator", "com/hpe/ucmdb/udc/action/DownloadAction$6", "run"));
                }
                try {
                    progressIndicator.setText("Connecting to the server and loading the data...");
                    final Map<String, Map<DiscoveryResType, List<DiscoveryResData>>> resGroup = new HashMap<String, Map<DiscoveryResType, List<DiscoveryResData>>>();
                    for (final DiscoveryResType resType : resTypes) {
                        final Collection<DiscoveryResData> discoveryResList = (Collection<DiscoveryResData>)udcHelper.listResources(resType);
                        for (final DiscoveryResData res : discoveryResList) {
                            String packageName = res.getPackageName();
                            if (packageName == null) {
                                continue;
                            }
                            if (packageName.endsWith(".zip")) {
                                packageName = packageName.substring(0, packageName.length() - 4);
                            }
                            Map<DiscoveryResType, List<DiscoveryResData>> resourcesPerPackageMap = resGroup.get(packageName);
                            if (resourcesPerPackageMap == null) {
                                resourcesPerPackageMap = new HashMap<DiscoveryResType, List<DiscoveryResData>>();
                                resGroup.put(packageName, resourcesPerPackageMap);
                            }
                            List<DiscoveryResData> resourcePerPackage = resourcesPerPackageMap.get(resType);
                            if (resourcePerPackage == null) {
                                resourcePerPackage = new ArrayList<DiscoveryResData>();
                                resourcesPerPackageMap.put(resType, resourcePerPackage);
                            }
                            resourcePerPackage.add(res);
                        }
                    }
                }
                catch (Exception e) {
                    PopupUtil.showBalloonForActiveFrame((e.getMessage() != null) ? e.getMessage() : "Error", MessageType.ERROR);
                    throw new RuntimeException(e);
                }
            }
        };
        ProgressManager.getInstance().run((Task)task);
    }
    
    public void update(final AnActionEvent e) {
        final VirtualFile data = (VirtualFile)e.getData(PlatformDataKeys.VIRTUAL_FILE);
        if (data == null) {
            e.getPresentation().setEnabled(false);
            return;
        }
        final Project project = e.getProject();
        if (project == null) {
            e.getPresentation().setEnabled(false);
            return;
        }
        final Module moduleForFile = ModuleUtil.findModuleForFile(data, project);
        if (moduleForFile == null) {
            e.getPresentation().setEnabled(false);
            return;
        }
        final boolean x = isRoot(moduleForFile, data);
        e.getPresentation().setEnabled(x);
    }
    
    public static boolean isRoot(@NotNull final Module module, @NotNull final VirtualFile dir) {
        if (module == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "module", "com/hpe/ucmdb/udc/action/DownloadAction", "isRoot"));
        }
        if (dir == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "dir", "com/hpe/ucmdb/udc/action/DownloadAction", "isRoot"));
        }
        return ProjectFileIndex.SERVICE.getInstance(module.getProject()).getContentRootForFile(dir).equals(dir);
    }
    
    static class TempData
    {
        Object o1;
        Object o2;
        Object o3;
        Object o4;
        List<String> subFol;
        
        public TempData(final Object o1, final Object o2, final Object o3, final Object o4, final List<String> subFol) {
            this.o1 = o1;
            this.o2 = o2;
            this.o3 = o3;
            this.o4 = o4;
            this.subFol = subFol;
        }
    }
}