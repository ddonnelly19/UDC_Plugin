/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.action;

import com.intellij.openapi.options.ShowSettingsUtil;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.AnAction;

public class Settings extends AnAction
{
    public void actionPerformed(final AnActionEvent e) {
        final Project project = (Project)e.getData(PlatformDataKeys.PROJECT);
        ShowSettingsUtil.getInstance().showSettingsDialog(project, "UDC Configuration");
    }
}