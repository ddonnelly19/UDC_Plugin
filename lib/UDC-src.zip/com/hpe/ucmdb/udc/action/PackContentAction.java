/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.action;

import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import com.hpe.ucmdb.udc.ResTypeUtil;
import com.intellij.openapi.vfs.VfsUtilCore;
import com.intellij.openapi.vfs.VirtualFileVisitor;
import com.intellij.openapi.application.ApplicationManager;
import java.util.Set;
import java.io.IOException;
import java.util.HashSet;
import java.io.ByteArrayOutputStream;
import java.util.jar.JarEntry;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.jar.JarOutputStream;
import java.io.FileOutputStream;
import com.intellij.openapi.actionSystem.DataContext;
import java.util.Iterator;
import com.intellij.openapi.project.Project;
import com.intellij.ide.SelectInContext;
import com.intellij.ide.FileSelectInContext;
import com.intellij.ide.projectView.ProjectView;
import com.intellij.ide.SelectInTarget;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.actionSystem.AnActionEvent;
import java.util.ArrayList;
import java.util.List;
import com.intellij.openapi.actionSystem.AnAction;

public class PackContentAction extends AnAction
{
    private List<String> packageCategory;
    
    public PackContentAction() {
        (this.packageCategory = new ArrayList<String>()).add("discoveryPatterns");
        this.packageCategory.add("discoveryModules");
        this.packageCategory.add("discoveryScripts");
        this.packageCategory.add("discoveryConfigFiles");
        this.packageCategory.add("discoveryResources");
        this.packageCategory.add("discoveryJobs");
        this.packageCategory.add("discoveryWizards");
        this.packageCategory.add("docs");
        this.packageCategory.add("discoverySaiResources");
        this.packageCategory.add("discoveryScannerConfiguration");
        this.packageCategory.add("discoveryMultiScannerPackage");
        this.packageCategory.add("discoveryManagementZones");
        this.packageCategory.add("serviceDiscoveryActivityType");
        this.packageCategory.add("serviceDiscoveryActivityTemplate");
    }
    
    public void actionPerformed(@NotNull final AnActionEvent event) {
        if (event == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "event", "com/hpe/ucmdb/udc/action/PackContentAction", "actionPerformed"));
        }
        final Project project = event.getProject();
        final VirtualFile root = (VirtualFile)event.getData(PlatformDataKeys.VIRTUAL_FILE);
        int i1 = 0;
        if (root.getParent().findChild(root.getName() + ".zip") != null) {
            final String s = "This destination already contains a ZIP file named '" + root.getName() + "'.zip. Do you still want to overwrite this ZIP file ? ";
            i1 = Messages.showOkCancelDialog(project, s, "Confirmation", "Yes", "No", Messages.getInformationIcon());
        }
        final List<VirtualFile> children = new ArrayList<VirtualFile>();
        for (final String packageN : this.packageCategory) {
            if (root.findChild(packageN) != null) {
                children.add(root.findChild(packageN));
            }
        }
        if (children.size() != 0) {
            if (i1 == 0) {
                try {
                    final byte[] zipContent = this.getZipContent(project, event.getDataContext(), root);
                    final String dirZipName = root.getName() + ".zip";
                    writeSingleResource(root.getParent(), dirZipName, zipContent);
                    Messages.showInfoMessage("The ZIP file '" + root.getName() + "' has been packed successfully and was saved to " + root.getCanonicalPath() + ".zip.", "Information");
                    final VirtualFile vf = root.getParent().findChild(dirZipName);
                    ProjectView.getInstance(event.getProject()).getSelectInTargets().toArray(new SelectInTarget[0])[0].selectIn((SelectInContext)new FileSelectInContext(event.getProject(), vf), true);
                }
                catch (Exception e) {
                    e.printStackTrace();
                    Messages.showErrorDialog(e.getMessage(), "Error");
                }
            }
        }
    }
    
    private void execute(final Project project, final DataContext dataContext, final VirtualFile[] vFiles, final String s) throws Exception {
        final JarOutputStream zos = new JarOutputStream(new FileOutputStream(s));
        try {
            for (final VirtualFile vf : vFiles) {
                final VirtualFile[] relatedVF;
                final VirtualFile[] children = relatedVF = this.getRelatedVF(vf);
                for (final VirtualFile child : relatedVF) {
                    final JarEntry ze = this.getEntry(child);
                    if (ze != null) {
                        zos.putNextEntry(ze);
                        zos.write(child.contentsToByteArray());
                        zos.closeEntry();
                        zos.flush();
                    }
                }
            }
            zos.finish();
        }
        finally {
            zos.close();
        }
    }
    
    private byte[] getZipContent(final Project project, final DataContext dataContext, final VirtualFile root) throws Exception {
        JarOutputStream zos = null;
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        zos = new JarOutputStream(bos);
        try {
            final Set<VirtualFile[]> childrenList = new HashSet<VirtualFile[]>();
            for (final String packageN : this.packageCategory) {
                if (root.findChild(packageN) != null) {
                    childrenList.add(this.getRelatedVF(root.findChild(packageN)));
                }
            }
            if (root.findChild("descriptor.xml") != null) {
                childrenList.add(this.getRelatedVF(root.findChild("descriptor.xml")));
            }
            for (final VirtualFile[] array : childrenList) {
                final VirtualFile[] children = array;
                for (final VirtualFile child : array) {
                    final JarEntry ze = this.getEntry(child);
                    if (ze != null) {
                        zos.putNextEntry(ze);
                        zos.write(child.contentsToByteArray());
                        zos.closeEntry();
                        zos.flush();
                    }
                }
            }
            zos.finish();
            return bos.toByteArray();
        }
        finally {
            try {
                zos.close();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    private static void writeSingleResource(final VirtualFile resTypeFolder, final String resourceName, final byte[] content) throws IOException {
        ApplicationManager.getApplication().runWriteAction((Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    final VirtualFile child = resTypeFolder.findOrCreateChildData((Object)null, resourceName);
                    child.setBinaryContent(content);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("Write to file:" + resourceName);
            }
        });
    }
    
    private VirtualFile[] getRelatedVF(final VirtualFile vf) {
        final List<VirtualFile> list = new ArrayList<VirtualFile>();
        final VirtualFileVisitor visitor = new VirtualFileVisitor(new VirtualFileVisitor.Option[0]) {
            public boolean visitFile(@NotNull final VirtualFile file) {
                if (file == null) {
                    throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "file", "com/hpe/ucmdb/udc/action/PackContentAction$2", "visitFile"));
                }
                if (!file.isDirectory()) {
                    list.add(file);
                }
                return true;
            }
        };
        VfsUtilCore.visitChildrenRecursively(vf, visitor);
        return list.toArray(new VirtualFile[list.size()]);
    }
    
    private JarEntry getEntry(final VirtualFile vf) throws IOException {
        final Object[] resourceName = ResTypeUtil.getResourceName(vf);
        if (resourceName != null && resourceName[0] != null && resourceName[1] != null) {
            final DiscoveryResType resType = (DiscoveryResType)resourceName[0];
            final String pathInZip = ResTypeUtil.getResName(resType) + "/" + resourceName[1];
            final JarEntry je = new JarEntry(pathInZip);
            je.setSize(vf.getLength());
            return je;
        }
        if (vf.getName().equals("descriptor.xml")) {
            final String pathInZip2 = "descriptor.xml";
            final JarEntry je2 = new JarEntry(pathInZip2);
            je2.setSize(vf.getLength());
            return je2;
        }
        return null;
    }
    
    public void update(final AnActionEvent e) {
        final VirtualFile data = (VirtualFile)e.getData(PlatformDataKeys.VIRTUAL_FILE);
        if (data == null) {
            e.getPresentation().setEnabled(false);
            return;
        }
        Boolean contain = true;
        final List<VirtualFile> children = new ArrayList<VirtualFile>();
        for (final String packageN : this.packageCategory) {
            if (data.findChild(packageN) != null) {
                children.add(data.findChild(packageN));
            }
        }
        if (children.size() == 0) {
            contain = false;
        }
        else {
            contain = true;
        }
        e.getPresentation().setEnabled((boolean)contain);
    }
}