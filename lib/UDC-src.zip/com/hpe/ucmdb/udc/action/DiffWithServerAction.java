/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc.action;

import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.progress.ProgressIndicator;
import com.intellij.openapi.diff.DiffManager;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import com.intellij.openapi.diff.DiffTool;
import com.hpe.ucmdb.udc.UDCSettings;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.diff.DiffRequest;
import com.intellij.openapi.diff.SimpleContent;
import com.intellij.openapi.progress.Task;
import com.intellij.openapi.progress.PerformInBackgroundOption;
import com.intellij.openapi.project.Project;
import com.hpe.ucmdb.udc.ServerConfig;
import com.intellij.openapi.diff.DiffContent;
import com.intellij.openapi.ui.popup.util.PopupUtil;
import com.intellij.openapi.ui.MessageType;
import com.hpe.ucmdb.udc.ResTypeUtil;
import com.hpe.ucmdb.udc.UDCHelper;
import com.hpe.ucmdb.udc.ServerConfigManager;
import com.intellij.openapi.diff.FileContent;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.AnAction;

public class DiffWithServerAction extends AnAction
{
    public void actionPerformed(final AnActionEvent e) {
        final VirtualFile file = ((VirtualFile[])e.getData(PlatformDataKeys.VIRTUAL_FILE_ARRAY))[0];
        final DiffContent local = (DiffContent)new FileContent(e.getProject(), file);
        final ServerConfig serverConfig = ServerConfigManager.getInstance().getDefaultServerConfig(e.getProject());
        if (serverConfig == null) {
            return;
        }
        final UDCHelper helper = new UDCHelper(e.getProject(), serverConfig);
        final Object[] resourceName = ResTypeUtil.getResourceName(file);
        if (resourceName == null) {
            PopupUtil.showBalloonForActiveComponent("Unknown type: " + file.getPath() + ".", MessageType.ERROR);
        }
        else {
            this.diff(e.getProject(), file, local, helper, resourceName);
        }
    }
    
    private void diff(final Project project, final VirtualFile file, final DiffContent local, final UDCHelper helper, final Object[] resourceName) {
        final Task.Backgroundable task = new Task.Backgroundable(project, "Diffing @" + ServerConfigManager.getInstance().getDefaultServerConfig(project).getServer(), false, new PerformInBackgroundOption() {
            public boolean shouldStartInBackground() {
                return true;
            }
            
            public void processSentToBackground() {
            }
        }) {
            byte[] content;
            
            public void onSuccess() {
                if (this.content != null) {
                    final DiffContent server = (DiffContent)new SimpleContent(new String(this.content));
                    server.getDocument().setReadOnly(false);
                    final DiffRequest dr = new DiffRequest(project) {
                        @NotNull
                        public DiffContent[] getContents() {
                            final DiffContent[] array = { local, server };
                            if (array == null) {
                                throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/action/DiffWithServerAction$2$1", "getContents"));
                            }
                            return array;
                        }
                        
                        public String[] getContentTitles() {
                            final String defaultServer = UDCSettings.getSettings(project).getState().defaultServer;
                            return new String[] { "Local", "Server : " + defaultServer };
                        }
                        
                        public String getWindowTitle() {
                            return file.getName();
                        }
                    };
                    dr.addHint(DiffTool.HINT_SHOW_NOT_MODAL_DIALOG);
                    dr.setOnOkRunnable((Runnable)new Runnable() {
                        @Override
                        public void run() {
                            try {
                                helper.setContent((DiscoveryResType)resourceName[0], (String)resourceName[1], server.getDocument().getText().getBytes());
                                PopupUtil.showBalloonForActiveFrame("Update server successfully.", MessageType.INFO);
                            }
                            catch (Exception e) {
                                PopupUtil.showBalloonForActiveFrame("Update server failure.", MessageType.ERROR);
                            }
                        }
                    });
                    DiffManager.getInstance().getDiffTool().show(dr);
                }
                else {
                    PopupUtil.showBalloonForActiveComponent("Can't get content from remote server.", MessageType.ERROR);
                }
            }
            
            public void run(@NotNull final ProgressIndicator progressIndicator) {
                if (progressIndicator == null) {
                    throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "progressIndicator", "com/hpe/ucmdb/udc/action/DiffWithServerAction$2", "run"));
                }
                progressIndicator.setIndeterminate(true);
                try {
                    this.content = helper.getContent((DiscoveryResType)resourceName[0], (String)resourceName[1]);
                }
                catch (Exception e1) {
                    e1.printStackTrace();
                    PopupUtil.showBalloonForActiveComponent("No such file in server.", MessageType.ERROR);
                    this.content = "".getBytes();
                }
            }
        };
        ProgressManager.getInstance().run((Task)task);
    }
    
    public void update(final AnActionEvent e) {
        final VirtualFile data = (VirtualFile)e.getData(PlatformDataKeys.VIRTUAL_FILE);
        if (data == null) {
            e.getPresentation().setEnabled(false);
            return;
        }
        final VirtualFile file = ((VirtualFile[])e.getData(PlatformDataKeys.VIRTUAL_FILE_ARRAY))[0];
        final Object[] resourceName = ResTypeUtil.getResourceName(file);
        final boolean x = isRoot(resourceName);
        e.getPresentation().setEnabled(x);
    }
    
    public static boolean isRoot(final Object[] resourceName) {
        return resourceName != null;
    }
}