/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.awt.event.MouseEvent;
import com.intellij.util.Consumer;
import org.jetbrains.annotations.Nullable;
import com.intellij.openapi.ui.popup.ListPopupStep;
import com.intellij.ui.popup.list.ListPopupImpl;
import com.intellij.openapi.ui.popup.PopupStep;
import com.intellij.openapi.ui.popup.util.BaseListPopupStep;
import com.intellij.openapi.ui.popup.ListPopup;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.Disposable;
import com.intellij.openapi.application.ApplicationManager;
import java.util.concurrent.TimeUnit;
import com.intellij.concurrency.JobScheduler;
import java.util.concurrent.ScheduledFuture;
import com.intellij.openapi.wm.StatusBar;
import com.intellij.openapi.wm.StatusBarWidget;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.openapi.project.Project;

public class StatusBarUtil
{
    public static final String DEFAULT_SERVER = "UDC Default Server";
    
    public static void setDefaultServerStatus(final Project project, final UDCSettings.State state) {
        final StatusBar statusBar = WindowManager.getInstance().getStatusBar(project);
        assert statusBar != null;
        DefaultServerStatusBarWidget widget = (DefaultServerStatusBarWidget)statusBar.getWidget("UDC Default Server");
        if (widget == null) {
            widget = new DefaultServerStatusBarWidget(state);
            statusBar.addWidget((StatusBarWidget)widget);
        }
        widget.setDefaultServer();
    }
    
    public static void setDefaultServerStatus(final Project project) {
        final UDCSettings.State state = UDCSettings.getSettings().getState();
        final StatusBar statusBar = WindowManager.getInstance().getStatusBar(project);
        assert statusBar != null;
        DefaultServerStatusBarWidget widget = (DefaultServerStatusBarWidget)statusBar.getWidget("UDC Default Server");
        if (widget == null) {
            widget = new DefaultServerStatusBarWidget(state);
            statusBar.addWidget((StatusBarWidget)widget);
        }
        widget.setDefaultServer();
    }
    
    static class DefaultServerStatusBarWidget implements StatusBarWidget
    {
        private ScheduledFuture<?> myFuture;
        StatusBar statusBar;
        private UDCSettings.State state;
        
        public DefaultServerStatusBarWidget(final UDCSettings.State state) {
            this.state = state;
            this.myFuture = JobScheduler.getScheduler().scheduleWithFixedDelay(new Runnable() {
                @Override
                public void run() {
                    DefaultServerStatusBarWidget.this.setDefaultServer();
                }
            }, 1L, 5L, TimeUnit.SECONDS);
            ApplicationManager.getApplication().getMessageBus().connect((Disposable)this).subscribe(DefaultServerChangeListener.TOPIC, (Object)new DefaultServerChangeListener() {
                public void defaultServerChanged() {
                    DefaultServerStatusBarWidget.this.setDefaultServer();
                }
            });
        }
        
        @NotNull
        public String ID() {
            final String s = "UDC Default Server";
            if (s == null) {
                throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/StatusBarUtil$DefaultServerStatusBarWidget", "ID"));
            }
            return s;
        }
        
        @Nullable
        public StatusBarWidget.WidgetPresentation getPresentation(@NotNull final StatusBarWidget.PlatformType platformType) {
            if (platformType == null) {
                throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "platformType", "com/hpe/ucmdb/udc/StatusBarUtil$DefaultServerStatusBarWidget", "getPresentation"));
            }
            return (StatusBarWidget.WidgetPresentation)new StatusBarWidget.MultipleTextValuesPresentation() {
                @Nullable
                public ListPopup getPopupStep() {
                    String[] options = (String[])DefaultServerStatusBarWidget.this.state.serverConfigs.keySet().toArray(new String[0]);
                    if (options.length == 0) {
                        options = new String[] { "NA" };
                    }
                    final ListPopupStep step = (ListPopupStep)new BaseListPopupStep<String>("DefaultServer", options) {
                        public PopupStep onChosen(final String selectedValue, final boolean finalChoice) {
                            if (finalChoice) {
                                DefaultServerStatusBarWidget.this.state.defaultServer = selectedValue;
                                DefaultServerStatusBarWidget.this.statusBar.updateWidget(DefaultServerStatusBarWidget.this.ID());
                                ((DefaultServerChangeListener)ApplicationManager.getApplication().getMessageBus().syncPublisher(DefaultServerChangeListener.TOPIC)).defaultServerChanged();
                            }
                            return super.onChosen((Object)selectedValue, finalChoice);
                        }
                    };
                    return (ListPopup)new ListPopupImpl(step);
                }
                
                @Nullable
                public String getSelectedValue() {
                    return "UDC: " + DefaultServerStatusBarWidget.this.state.defaultServer;
                }
                
                @NotNull
                public String getMaxValue() {
                    final String s = "1234567890";
                    if (s == null) {
                        throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/StatusBarUtil$DefaultServerStatusBarWidget$3", "getMaxValue"));
                    }
                    return s;
                }
                
                @Nullable
                public String getTooltipText() {
                    return null;
                }
                
                @Nullable
                public Consumer<MouseEvent> getClickConsumer() {
                    return null;
                }
            };
        }
        
        public void install(@NotNull final StatusBar statusBar) {
            if (statusBar == null) {
                throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "statusBar", "com/hpe/ucmdb/udc/StatusBarUtil$DefaultServerStatusBarWidget", "install"));
            }
            this.statusBar = statusBar;
        }
        
        public void setDefaultServer() {
            this.statusBar.updateWidget(this.ID());
        }
        
        public void dispose() {
            if (this.myFuture != null) {
                this.myFuture.cancel(true);
                this.myFuture = null;
            }
        }
    }
}