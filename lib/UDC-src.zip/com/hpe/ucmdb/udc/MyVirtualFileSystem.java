/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.io.IOException;
import com.intellij.openapi.vfs.VirtualFileListener;
import org.jetbrains.annotations.Nullable;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import com.intellij.openapi.vfs.VirtualFileSystem;

public class MyVirtualFileSystem extends VirtualFileSystem
{
    @NotNull
    public String getProtocol() {
        final String s = "ucmdb";
        if (s == null) {
            throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "getProtocol"));
        }
        return s;
    }
    
    @Nullable
    public VirtualFile findFileByPath(@NotNull @NonNls final String s) {
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "findFileByPath"));
        }
        return null;
    }
    
    public void refresh(final boolean b) {
    }
    
    @Nullable
    public VirtualFile refreshAndFindFileByPath(@NotNull final String s) {
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "refreshAndFindFileByPath"));
        }
        return null;
    }
    
    public void addVirtualFileListener(@NotNull final VirtualFileListener virtualFileListener) {
        if (virtualFileListener == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFileListener", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "addVirtualFileListener"));
        }
    }
    
    public void removeVirtualFileListener(@NotNull final VirtualFileListener virtualFileListener) {
        if (virtualFileListener == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFileListener", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "removeVirtualFileListener"));
        }
    }
    
    protected void deleteFile(final Object o, @NotNull final VirtualFile virtualFile) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "deleteFile"));
        }
    }
    
    protected void moveFile(final Object o, @NotNull final VirtualFile virtualFile, @NotNull final VirtualFile virtualFile2) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "moveFile"));
        }
        if (virtualFile2 == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile2", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "moveFile"));
        }
    }
    
    protected void renameFile(final Object o, @NotNull final VirtualFile virtualFile, @NotNull final String s) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "renameFile"));
        }
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "renameFile"));
        }
    }
    
    protected VirtualFile createChildFile(final Object o, @NotNull final VirtualFile virtualFile, @NotNull final String s) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "createChildFile"));
        }
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "createChildFile"));
        }
        return null;
    }
    
    @NotNull
    protected VirtualFile createChildDirectory(final Object o, @NotNull final VirtualFile virtualFile, @NotNull final String s) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "createChildDirectory"));
        }
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "createChildDirectory"));
        }
        final VirtualFile virtualFile2 = null;
        if (virtualFile2 == null) {
            throw new IllegalStateException(String.format("@NotNull method %s.%s must not return null", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "createChildDirectory"));
        }
        return virtualFile2;
    }
    
    protected VirtualFile copyFile(final Object o, @NotNull final VirtualFile virtualFile, @NotNull final VirtualFile virtualFile2, @NotNull final String s) throws IOException {
        if (virtualFile == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "copyFile"));
        }
        if (virtualFile2 == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "virtualFile2", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "copyFile"));
        }
        if (s == null) {
            throw new IllegalArgumentException(String.format("Argument for @NotNull parameter '%s' of %s.%s must not be null", "s", "com/hpe/ucmdb/udc/MyVirtualFileSystem", "copyFile"));
        }
        return null;
    }
    
    public boolean isReadOnly() {
        return true;
    }
}