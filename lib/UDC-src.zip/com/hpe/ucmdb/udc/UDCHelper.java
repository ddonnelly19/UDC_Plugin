/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import java.util.Map;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import com.intellij.openapi.progress.ProgressManager;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.zip.ZipEntry;
import java.io.OutputStream;
import java.util.zip.ZipOutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.ArrayList;
import com.intellij.openapi.vfs.VirtualFile;
import com.hp.ucmdb.api.discovery.types.DiscoveryResData;
import java.util.Collection;
import com.hp.ucmdb.api.discovery.types.DiscoveryResType;
import com.intellij.openapi.project.Project;

public class UDCHelper
{
    public static final String DISCOVERYSCRIPTS = "discoveryScripts";
    private Project project;
    ServerConfig config;
    
    private UDCHelper(final ServerConfig config) {
        this.config = config;
    }
    
    public UDCHelper(final Project project, final ServerConfig serverConfig) {
        this(serverConfig);
        this.project = project;
    }
    
    public Collection<DiscoveryResData> listResources(final DiscoveryResType type) throws Exception {
        return (Collection<DiscoveryResData>)UcmdbClient.getUcmdbClient(this.project).listResources(type);
    }
    
    public byte[] getContent(final DiscoveryResType type, final String name) throws Exception {
        return UcmdbClient.getUcmdbClient(this.project).getResourceContent(type, name);
    }
    
    public void setContent(final DiscoveryResType type, final String name, final byte[] content) throws Exception {
        UcmdbClient.getUcmdbClient(this.project).setResourceContent(type, name, content);
    }
    
    @Deprecated
    private int pushByPackage(final Project project, final VirtualFile[] vFiles) throws IOException {
        final List<VirtualFile> allFiles = new ArrayList<VirtualFile>();
        for (final VirtualFile vf : vFiles) {
            if (vf.isDirectory()) {
                final VirtualFile[] children = vf.getChildren();
                allFiles.addAll(Arrays.asList(children));
            }
            else {
                allFiles.add(vf);
            }
        }
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        final ZipOutputStream zos = new ZipOutputStream(baos);
        for (final VirtualFile vf : allFiles) {
            zos.putNextEntry(new ZipEntry("discoveryScripts/" + vf.getName()));
            zos.write(vf.contentsToByteArray());
            zos.closeEntry();
        }
        zos.finish();
        zos.close();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    final UcmdbClient uc = UcmdbClient.getUcmdbClient(project);
                    uc.deployPackage("hello.zip", (InputStream)new ByteArrayInputStream(baos.toByteArray()));
                }
                catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        };
        ProgressManager.getInstance().runProcessWithProgressSynchronously(runnable, "Push", true, project);
        return allFiles.size();
    }
    
    public void createPackage(final String name) throws Exception {
        final ByteArrayOutputStream out = new ByteArrayOutputStream();
        final ZipOutputStream zos = new ZipOutputStream(out);
        zos.putNextEntry(new ZipEntry("discoveryResources/dummy_" + name + ".txt"));
        final String s = "This file is a place holder for creating a empty package.";
        zos.write(s.getBytes());
        zos.closeEntry();
        zos.close();
        final ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
        System.out.println("Begin deploy");
        UcmdbClient.getUcmdbClient(this.project).deployPackage(name, (InputStream)in);
    }
    
    public Map<String, Object>[] getHistory(final String name) throws Exception {
        return (Map<String, Object>[])UcmdbClient.getUcmdbClient(this.project).getHistory(name);
    }
    
    public byte[] getRevisionContent(final String resourceName, final long revision) throws Exception {
        return UcmdbClient.getUcmdbClient(this.project).getRevisionContent(resourceName, revision);
    }
}