/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.hpe.ucmdb.udc;

import javax.swing.JComponent;
import com.intellij.uiDesigner.core.Spacer;
import java.awt.Dimension;
import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import java.awt.Insets;
import java.awt.AWTEvent;
import java.awt.Window;
import com.intellij.ui.EditorTextField;
import javax.swing.KeyStroke;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.Container;
import com.intellij.openapi.project.Project;
import com.intellij.lang.Language;
import com.intellij.ui.LanguageTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JDialog;

public class FileUI extends JDialog
{
    private JPanel contentPane;
    private JButton buttonOK;
    private JPanel JP1;
    public LanguageTextField editorPane1;
    
    public FileUI(final Language xml, final Project project, final String text) {
        this.$$$setupUI$$$();
        this.setContentPane(this.contentPane);
        this.setModal(true);
        final EditorTextField etf = (EditorTextField)new LanguageTextField(xml, project, text, false);
        final JScrollPane scroll = new JScrollPane(etf.getComponent(), 20, 32);
        final BorderLayout mgr = new BorderLayout();
        this.JP1.setLayout(mgr);
        this.JP1.add(scroll, "Center");
        this.getRootPane().setDefaultButton(this.buttonOK);
        this.setBounds(0, 0, 800, 600);
        this.setLocationRelativeTo(null);
        this.buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                try {
                    FileUI.this.quit();
                }
                catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });
        this.setDefaultCloseOperation(0);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(final WindowEvent e) {
                FileUI.this.onCancel();
            }
        });
        this.contentPane.registerKeyboardAction(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                FileUI.this.onCancel();
            }
        }, KeyStroke.getKeyStroke(27, 0), 1);
    }
    
    public void quit() throws Exception {
        this.dispatchEvent(new WindowEvent(this, 201));
    }
    
    private void onOK() {
        this.dispose();
    }
    
    private void onCancel() {
        this.dispose();
    }
    
    public static void main(final String[] args) {
        final FileUI dialog = new FileUI(null, null, (String)null);
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
    
    private  void $$$setupUI$$$() {
        final JPanel contentPane = new JPanel();
        (this.contentPane = contentPane).setLayout((LayoutManager)new GridLayoutManager(2, 1, new Insets(10, 10, 10, 10), -1, -1, false, false));
        final JPanel panel = new JPanel();
        panel.setLayout((LayoutManager)new GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(panel, new GridConstraints(1, 0, 1, 1, 0, 3, 3, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        panel.add((Component)new Spacer(), new GridConstraints(0, 0, 1, 1, 0, 1, 6, 1, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel panel2 = new JPanel();
        panel2.setLayout((LayoutManager)new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
        panel.add(panel2, new GridConstraints(0, 1, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
        final JButton buttonOK = new JButton();
        (this.buttonOK = buttonOK).setText("OK");
        panel2.add(buttonOK, new GridConstraints(0, 0, 1, 1, 0, 1, 3, 0, (Dimension)null, (Dimension)null, (Dimension)null));
        final JPanel jp1 = new JPanel();
        (this.JP1 = jp1).setLayout((LayoutManager)new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1, false, false));
        contentPane.add(jp1, new GridConstraints(0, 0, 1, 1, 0, 3, 3, 3, (Dimension)null, (Dimension)null, (Dimension)null));
    }
}