# coding=utf-8
# file location : DDMInfra\discoveryScripts\active_directory_utils.py
from active_directory_utils import LdapEnvironmentBuilder
# file location : AutoDiscoveryContent\discoveryScripts
import logger


def DiscoveryMain(Framework):
    credentialsId = Framework.getDestinationAttribute('credentials_id')
    applicationPort = Framework.getDestinationAttribute("application_port")
    serviceAddressPort = Framework.getDestinationAttribute('port')

    if not applicationPort or applicationPort == 'NA':
        applicationPort = serviceAddressPort

    client = None
    try:
        # build environment and connect
        envBuilder = LdapEnvironmentBuilder(applicationPort)
        client = Framework.createClient(credentialsId, envBuilder.build())

        # parameters of method executeQuery : String name, String filter, String[] attributeIds
        siteRs = client.executeQuery('CN=Sites,CN=Configuration,DC=ud,DC=hpswlabs,DC=hp,DC=com',
                                     '(objectClass=site)',
                                     ['name', 'distinguishedName'])
        while siteRs.next():
            logger.debug("distinguishedName : ", siteRs.getString('distinguishedName'))
            logger.debug("name : ", siteRs.getString('name'))
        siteRs.close()
    except:
        logger.warnException("Failed connection")
    finally:
        client and client.close()

