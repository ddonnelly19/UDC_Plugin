# coding=utf-8

from java.util import Properties

# file location : AutoDiscoveryContent\discoveryScripts
import errorcodes
import errorobject
import logger
import netutils

from com.hp.ucmdb.discovery.library.clients import ClientsConsts
from appilog.common.system.types.vectors import ObjectStateHolderVector
from com.hp.ucmdb.discovery.common import CollectorsConstants
from snmp_model_finder import SnmpQueryHelper, SnmpStateHolder, SnmpHelper


def DiscoveryMain(Framework):
    _vector = ObjectStateHolderVector()

    # get ip_domain and ip_address by adapter's "Triggered CI data"
    ip_domain = Framework.getDestinationAttribute('ip_domain')
    ip_address = Framework.getDestinationAttribute('ip_address')

    # connection established
    protocols = netutils.getAvailableProtocols(Framework, ClientsConsts.SNMP_PROTOCOL_NAME, ip_address, ip_domain)
    if len(protocols) == 0:
        errStr = 'No credentials defined for the triggered ip'
        logger.debug(errStr)
        errObj = errorobject.createError(errorcodes.NO_CREDENTIALS_FOR_TRIGGERED_IP, [ClientsConsts.SNMP_PROTOCOL_NAME],
                                         errStr)
        return (_vector, errObj)

    for protocol in protocols:
        logger.debug('try to get snmp agent for: %s:%s' % (ip_address, ip_domain))

        properties = Properties()
        properties.setProperty(CollectorsConstants.DESTINATION_DATA_IP_ADDRESS, ip_address)
        properties.setProperty(CollectorsConstants.DESTINATION_DATA_IP_DOMAIN, ip_domain)
        client = Framework.createClient(protocol, properties)

        # use SnmpQueryHelper to query OID
        snmpQueryHelper = SnmpQueryHelper(client)

        # snmpQueryHelper.snmpGet() returns a tuple (OID , value) by OID via SNMP GET method
        oid_sysName = snmpQueryHelper.snmpGet('1.3.6.1.2.1.1.5.0')

        # snmpQueryHelper.snmpNext() returns a tuple (OID , value) by OID via SNMP GETNEXT method
        oid_nextIpAdd = snmpQueryHelper.snmpNext('1.3.6.1.2.1.4.20')

        # snmpQueryHelper.snmpGet() returns tuples (OID , value) by OID via SNMP WALK method
        oid_walkIpAdd = snmpQueryHelper.snmpWalk('1.3.6.1.2.1.4.20')

        logger.debug('snmpQueryHelperGet sysName : ', oid_sysName)
        logger.debug('snmpQueryHelperNext ip address : ', oid_nextIpAdd)
        logger.debug('snmpQueryHelperWalk ip address table : ', oid_walkIpAdd)



        # use SnmpHelper to query OID
        snmpStateHolder = SnmpStateHolder()
        snmpHelper = SnmpHelper(snmpStateHolder, snmpQueryHelper)

        # snmpHelper.snmpGetValue() returns a value by OID via SNMP GET method
        sysName = snmpHelper.snmpGetValue('1.3.6.1.2.1.1.5.0')

        # snmpHelper.snmpGet() returns a tuple (OID , value) by OID via SNMP GET method
        oid_sysName = snmpHelper.snmpGet('1.3.6.1.2.1.1.5.0')

        # snmpQueryHelper.snmpNext() returns a tuple (OID , value) by OID via SNMP GETNEXT method
        oid_nextIpAdd = snmpHelper.snmpNext('1.3.6.1.2.1.4.20')

        # snmpQueryHelper.snmpGet() returns tuples (OID , value) by OID via SNMP WALK method
        oid_walkIpAdd = snmpHelper.snmpWalk('1.3.6.1.2.1.4.20')

        # snmpQueryHelper.snmpGet() returns a table values  by OID via SNMP WALK method
        walkIpAdd = snmpHelper.snmpWalkValue('.1.3.6.1.2.1.4.20')

        logger.debug('snmpHelperGetValue sysName : ', sysName)
        logger.debug('snmpHelperGet sysName : ', oid_sysName)
        logger.debug('snmpHelperNext ip address :', oid_nextIpAdd)
        logger.debug('snmpHelperWalk ip address table : ', oid_walkIpAdd)
        logger.debug('snmpHelperWalkValue ip address table : ', walkIpAdd)

        client.close()
