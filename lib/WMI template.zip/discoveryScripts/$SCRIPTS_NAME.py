# coding=utf-8

from java.util import Properties

# file location : AutoDiscoveryContent\discoveryScripts
import logger
import netutils
from com.hp.ucmdb.discovery.library.clients import ClientsConsts
from com.hp.ucmdb.discovery.common import CollectorsConstants



def DiscoveryMain(Framework):

    # get ip_domain and ip_address by adapter's "Triggered CI data"
    ip_domain = Framework.getDestinationAttribute('ip_domain')
    ip_address = Framework.getDestinationAttribute('ip_address')

    credentials = netutils.getAvailableProtocols(Framework, ClientsConsts.WMI_PROTOCOL_NAME, str(ip_address), ip_domain)

    for credential in credentials:
        try:
            # build connection
            debug_string = ip_domain + "\\" + str(ip_address)
            props = Properties()
            props.setProperty(CollectorsConstants.DESTINATION_DATA_IP_ADDRESS, ip_address)
            logger.debug('try to get wmi agent for: ', debug_string)
            client = Framework.createClient(credential, props)
            # set query
            wmiQuery = 'select Caption,Version,ServicePackMajorVersion,ServicePackMinorVersion,BuildNumber from Win32_OperatingSystem'
            resultSet = client.executeQuery(wmiQuery)  # @@CMD_PERMISION wmi protocol execution
            if resultSet.next():
                caption = resultSet.getString(1)
                version = resultSet.getString(2)
                servicePackMajorVersion = resultSet.getString(3)
                servicePackMinorVersion = resultSet.getString(4)
                buildNumber = resultSet.getString(5)

                logger.debug("caption: ", caption)
                logger.debug("version: ", version)
                logger.debug("servicePackMajorVersion: ", servicePackMajorVersion)
                logger.debug("servicePackMinorVersion: ", servicePackMinorVersion)
                logger.debug("buildNumber: ", buildNumber)

        except Exception, ex:
            logger.warn(ex)
        finally:
            resultSet.close()
            client.close()

