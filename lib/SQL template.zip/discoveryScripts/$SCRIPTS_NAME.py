# coding=utf-8
from java.lang import Exception as JavaException
from java.util import Properties, HashSet
from com.hp.ucmdb.discovery.common import CollectorsConstants

# file location : AutoDiscoveryContent\discoveryScripts
import logger

from com.hp.ucmdb.discovery.library.clients import ClientsConsts, \
    MissingJarsException
from appilog.common.utils import Protocol


def DiscoveryMain(Framework):

    # set connection

    ipAddressList = Framework.getTriggerCIDataAsList('ip_address')
    destinationPortList = Framework.getTriggerCIDataAsList('application_port')
    sidList = Framework.getTriggerCIDataAsList('sid')
    protocols = Framework.getAvailableProtocols(ClientsConsts.SQL_PROTOCOL_NAME)
    for protocolId in protocols:

      logger.debug('Connecting by protocol %s' % protocolId)
      for ipAddress in ipAddressList:
            for destinationPort in destinationPortList:
                for sid in sidList:
                    client = None
                    try:
                        props = Properties()
                        props.setProperty(CollectorsConstants.DESTINATION_DATA_IP_ADDRESS, ipAddress)
                        props.setProperty(CollectorsConstants.PROTOCOL_ATTRIBUTE_PORT, destinationPort)
                        props.setProperty(Protocol.SQL_PROTOCOL_ATTRIBUTE_DBSID, sid)
                        props.setProperty(Protocol.SQL_PROTOCOL_ATTRIBUTE_DBNAME, sid)
                        client = Framework.createClient(protocolId, props)
                        if client:
                            logger.debug('Connection by protocol %s success!' % protocolId)
                        # execute sql query
                        host_name_result = client.executeQuery(
                            "select UTL_INADDR.get_host_name(UTL_INADDR.get_host_address) from dual")
                        # client.executeQuery("create table t_student( name varchar2(20), age number(4))")
                        # client.executeQuery("INSERT INTO t_student (name, age) VALUES ('Nick', 90)")
                        student = client.executeQuery("select * from t_student")
                        while host_name_result.next():
                            logger.debug("result : ", host_name_result.getString(1))
                        while student.next():
                            logger.debug("student's name : ", student.getString(1))
                            logger.debug("student's age : ", student.getString(2))
                        student.close()
                    except (MissingJarsException, JavaException), ex:
                        strException = ex.getMessage()
                        logger.debug(strException)
                        logger.debugException('')

                    except Exception, ex:
                        strException = str(ex)
                        logger.debug(strException)
                        logger.debugException('')
                    if client:
                        client.close()




