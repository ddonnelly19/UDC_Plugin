# coding=utf-8
from appilog.common.system.types.vectors import ObjectStateHolderVector

# file location : AutoDiscoveryContent\discoveryScripts
import modeling
import logger




def DiscoveryMain(Framework):
    vector = ObjectStateHolderVector()

    ipAddress1 = "1.1.1.1"
    # create CI
    ipOSH1 = modeling.createIpOSH(ipAddress1)

    hostOSH1 = modeling.createHostOSH(ipAddress1)

    interfaceOSH = modeling.createInterfaceOSH("00:50:56:AA:3C:C2")

    containment = modeling.createLinkOSH('containment', hostOSH1,ipOSH1)
    logger.debug("containment link : ",containment)

    interfaceOSH.setContainer(hostOSH1)

    vector.add(containment)
    vector.add(ipOSH1)
    vector.add(hostOSH1)
    vector.add(interfaceOSH)

    return vector
