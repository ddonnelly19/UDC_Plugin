# coding=utf-8

# file location : AutoDiscoveryContent\discoveryScripts
import logger
import rest_requests as requests


def DiscoveryMain(Framework):
    url = 'https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22shanghai%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys'

    """
        @param url: http request url
        @param debug : if debug, logger.debug('Request method: %s and URL: %s' % (method, url))
        @param verify: whether verify ssl certificate, True or False
        you can learn more parameters information from the source code of 'request' method
        @return:
    """
    rsp = requests.get(url, debug=True, verify=False)

    # get response's text in json format
    rspjson = rsp.json()

    # get response's text
    logger.debug('rsp.text , ', rsp.text)

    # get response's status code
    logger.debug('rsp.status_code , ', rsp.status_code)

    # get proper information in json
    for key, value in rspjson[u'query'][u'results'][u'channel'][u'location'].iteritems():
        logger.debug(key + " : ", value)

    for x in rspjson[u'query'][u'results'][u'channel'][u'item'][u'forecast']:
        for key, value in x.iteritems():
            logger.debug(key + " : ", value)
